
package ts.support;
import java.util.*;
import ts.Message;
import ts.tree.*;
import java.util.*;

/*
 * TSArray
 */


public final class TSArray extends TSObject
{
    private ArrayList<TSValue> elements;
    
    
    //constructor
    private TSArray()
    {
        super(null);
        this.elements = new ArrayList<TSValue>();
    }
    
    //constructor
    private TSArray(ArrayList<TSValue> list)
    {
        super(null);
        this.elements = new ArrayList<TSValue>(list);
    }
    
    
    //constructor
    public static TSArray create()
    {
        TSArray ret =  new TSArray();
        ret.put(TSString.create("push"), TSFunctionObject.create(ret.new pushArray(),null));
        ret.put(TSString.create("toStr"), TSFunctionObject.create(ret.new toStr(),null));
        return ret;
    }
    
    //constructor
    public static TSArray create(ArrayList<TSValue> list)
    {
        TSArray ret =  new TSArray(list);
        ret.put(TSString.create("push"), TSFunctionObject.create(ret.new pushArray(),null));
        ret.put(TSString.create("toStr"), TSFunctionObject.create(ret.new toStr(),null));
        return ret;
    }
    
    public void push(TSValue value)
    {
        this.elements.add(value);
        this.put("length", TSNumber.create(elements.size()));
    }
    
    public TSValue get(String name)
    {
        if (name.matches("[0-9]+"))
            return get(TSValue.make(name));
        
        
        if(name.equals("prototype"))
        {
            if(hasPrototype())
                return prototype;
            else
                return null;
        }
        
        if(property.containsKey(name))
            return property.get(name);
        
        if(hasPrototype())
            return prototype.get(name);
        else
            return TSUndefined.value;
        
    }
    
    public TSValue get(TSValue index)
    {
        int ind = (int)index.toNumber().getInternal();
        
        if(ind < 0 || ind >= elements.size())
            throw new TSException("index out of range: " + ind);

        return elements.get(ind);
    }
    
    class pushArray implements TSCode
    {
        public pushArray() {}
        public TSValue execute(boolean isConstructorCall, TSValue ths,
                               TSValue args[], TSEnvironment env)
        {
            if(!(ths instanceof TSArray) || args == null)
                Message.fatal("Error when push to array");
            else
            {
                
                TSArray temp = (TSArray)ths;
                for (TSValue elem : args)
                    temp.push(elem);
                
                return TSBoolean.trueValue;
            }
            return TSUndefined.value;
        }
    }
    
    class toStr implements TSCode
    {
        public toStr() {}
        public TSValue execute(boolean isConstructorCall, TSValue ths,
                               TSValue args[], TSEnvironment env)
        {
            String ret = "";
            for( TSValue elem : elements )
            {
                ret += elem.toStr().getInternal() + " ";
            }
            
            return TSValue.make(ret);
        }
    }
}