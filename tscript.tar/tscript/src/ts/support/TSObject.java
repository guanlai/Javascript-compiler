
package ts.support;
import java.util.*;
import ts.Message;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
/*
 * TSObject
 */


public class TSObject extends TSValue
{
    protected Map<String,TSValue> property;
    protected TSObject prototype = null;
    public static TSObject globalObject = new TSObject(null);
    private static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

    protected TSObject(TSObject prototype)
    {
        property = new HashMap<String,TSValue>();
        this.prototype = prototype;
    }
    
    
    public static TSObject create()
    {
        return new TSObject(null);
    }
    
    
    public static TSObject create(TSObject prototype)
    {
        return new TSObject(prototype);
    }
    
    public TSValue get(String name)
    {
        if(name.equals("prototype"))
        {
            if(hasPrototype())
                return prototype;
            else
                return null;
        }
        
        if(property.containsKey(name))
            return property.get(name);
        
        if(hasPrototype())
            return prototype.get(name);
        else
            return TSUndefined.value;
    }
    
    public TSValue get(TSValue name)
    {
        return get( name.toPrimitive().toStr().getInternal());
    }
    
    public void put(String name, TSValue value)
    {
        if(name.equals("prototype"))
        {
            if(value instanceof TSObject)
            {
                prototype = (TSObject)value;
            }
            else
            {
                Message.fatal("prototype must be a TSObject");
            }
        }
        else
            property.put(name, value);
    }
    
    public void put(TSValue name, TSValue value)
    {
        String temp = name.toPrimitive().toStr().getInternal();
        put( temp, value );
    }
    
    //put2 for globalObject
    public void put2(String name, TSValue value)
    {
        globalObject.property.put(name, value);
    }
    
    //get2 for globalObject
    public TSValue get2(String name)
    {
        if(!(property.containsKey("NaN")))
        {//load three value before the first query
            globalObject.put2("NaN", TSNumber.create(Double.NaN));
            globalObject.put2("Infinity", TSNumber.create(Double.POSITIVE_INFINITY));
            globalObject.put2("undefined", TSUndefined.value);
            globalObject.put2("readln", TSFunctionObject.create(new readln(), null));
            globalObject.put2("split", TSFunctionObject.create(new split(), null));
            globalObject.put2("isNaN", TSFunctionObject.create(new isNaN(), null));
            globalObject.put2("isFinite", TSFunctionObject.create(new isFinite(), null));
            TSObject test1 = TSObject.create();
            test1.put("printXYZ", TSFunctionObject.create(new printXYZ(), null));
            TSObject test2 = TSFunctionObject.create(new testThis(), null);
            test2.put("prototype", test1);
            globalObject.put2("testThis", test2);
        }
        
        if(globalObject.property.containsKey(name))
            return property.get(name);
        if(true)
            throw new TSException("undefined identifier: " + name);
        return TSUndefined.value;
    }
    
    public boolean hasPrototype()
    {
        return prototype != null;
    }
    
    
    public boolean hasProperty(String name)
    {
        if(property.containsKey(name))
            return true;
        
        if(hasPrototype())
            return prototype.hasProperty(name);
        else
            return false;
    }
    
    public boolean hasOwnProperty(String name)
    {
        return property.containsKey(name);
    }
    
    public boolean deleteProperty(String name)
    {
        return property.remove(name) != null;
    }
    
    public TSObject callConstructor(TSValue args[])
    {
        if( hasPrototype() )
        {
            return create(prototype);
        }
        return create();
    }
    
    //readln
    class readln implements TSCode
    {
        public readln() {}
        public TSValue execute(boolean isConstructorCall,
                               TSValue ths,
                               TSValue args[],
                               TSEnvironment env)
        {
            try{
                String input = in.readLine();
                if(input == null)
                {
                    return TSNull.value;
                }
                else
                {
                    return TSString.create(input);
                }
            } catch (IOException e) {
                Message.executionError("readln() error");
            }
            return TSUndefined.value;
        }
    }
    
    //isNaN
    class isNaN implements TSCode
    {
        public isNaN() {}
        public TSValue execute(boolean isConstructorCall,
                               TSValue ths,
                               TSValue args[],
                               TSEnvironment env)
        {
            if(args.length > 0)
            {
                double temp = args[0].toPrimitive().toNumber().getInternal();
                return TSBoolean.create(Double.isNaN( temp ));
            }
            return TSBoolean.falseValue;
        }
    }
    
    //isFinite
    class isFinite implements TSCode
    {
        public isFinite() {}
        
        public TSValue execute(boolean isConstructorCall,
                               TSValue ths,
                               TSValue args[],
                               TSEnvironment env)
        {
            if(args.length > 0)
            {
                double temp = args[0].toPrimitive().toNumber().getInternal();
                return TSBoolean.create(!Double.isInfinite( temp ) && !Double.isNaN( temp ));
            }
            return TSBoolean.falseValue;
        }
    }
    
    //testThis
    class testThis implements TSCode
    {
        public testThis() {};
        
        public TSValue execute(boolean isConstructorCall,
                               TSValue ths,
                               TSValue args[],
                               TSEnvironment env)
        {
            if(!(ths instanceof TSObject))
            {
                Message.fatal("testThis: \"ths\" should be an object");
            }
            
            //put2("xyz",TSNumber.create(42));
            if( ths == null )
            {
                ths = globalObject;
            }
            ((TSObject)ths).put("xyz",TSNumber.create(42));
            //put("xyz",TSNumber.create(42));
            
            return ths;
        }
    }
    
    //printXYZ
    class printXYZ implements TSCode
    {
        public printXYZ() {}
        public TSValue execute(boolean isConstructorCall,
                               TSValue ths,
                               TSValue args[],
                               TSEnvironment env)
        {
            if(!(ths instanceof TSObject))
            {
                Message.fatal("testThis: \"ths\" should be an object");
            }
            System.out.println((int)(((TSObject)ths).get("xyz").toNumber().getInternal()));
            return TSUndefined.value;
        }
    }
    
    //toPrimitive
    public TSPrimitive toPrimitive()
    {
        return defaultValue(1).toPrimitive();
    }
    
    public TSString toStr()
    {
        return defaultValue(0).toStr();
    }
    
    public TSNumber toNumber()
    {
        
        return defaultValue(1).toNumber();
    }
    
    public TSBoolean toBoolean()
    {
        return TSBoolean.trueValue;
    }
    
    
    private TSValue defaultValue(final int hint)
    {
        //hint 0: string
        //hint 1: number
        if (hint == 0)
        {
            
            TSValue toString = this.get("toString").getValue();
            if (toString instanceof TSFunctionObject)
            {
                TSValue str = ((TSFunctionObject)toString).runFunction(false,this,null);
                if(str instanceof TSPrimitive)
                    return str;
            }
            
            TSValue valueOf = this.get("valueOf");
            if (valueOf instanceof TSFunctionObject)
            {
                TSValue val = ((TSFunctionObject)valueOf).runFunction(false,this,null).getValue();
                if (val  instanceof TSPrimitive )
                    return val;
            }
        }
        
        if(hint == 1){
            TSValue valueOf = this.get("valueOf");
            if (valueOf instanceof TSFunctionObject)
            {
                TSValue val = ((TSFunctionObject)valueOf).runFunction(false,this,null).getValue();
                if (val instanceof TSPrimitive)
                    return val;
            }
            
            TSValue toString = this.get("toString").getValue();
            if (toString instanceof TSFunctionObject)
            {
                TSValue str = ((TSFunctionObject)toString).runFunction(false,this,null);
                if(str instanceof TSPrimitive )
                    return str;
            }
        }
        throw new TSException("Type Error");
    }
    
    //split a string into TSArray
    
    class split implements TSCode
    {
        public split() {}
        public TSValue execute(boolean isConstructorCall, TSValue ths,
                               TSValue args[], TSEnvironment env)
        {
            if(args == null || !(args[0] instanceof TSString))
                Message.fatal("can only split String");
            
            TSArray ret = TSArray.create();
            if(args.length == 1)
            {
                ret.push(args[0]);
            }
            else
            {
                String[] arr = args[0].toStr().getInternal().split(args[1].toStr().getInternal());
                
                for(String s : arr)
                    ret.push(TSString.create(s));
            }
            
            return ret;
            
        }
        
    }
}