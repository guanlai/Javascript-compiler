
package ts.support;
import java.util.*;
import ts.Message;
import ts.tree.*;
import java.util.*;

/*
 * TSFunctionObject
 */


public final class TSFunctionObject extends TSObject
{
    private TSCode code;
    private TSEnvironment env;

    //constructor
    private TSFunctionObject(final TSCode code,
                             final TSEnvironment env)
    {
        super(null);
        this.code = code;
        this.env = env;
    }
    
    //helper function for constructor
    //@return function object
    public static TSFunctionObject create(final TSCode code,
                                          final TSEnvironment env)
    {
        return new TSFunctionObject(code, env);
    }
    
    //@return function code
    public TSCode getCode()
    {
        return code;
    }

    //@return function environment
    public TSEnvironment getEnv()
    {
        return env;
    }
    
    //@return function call
    public TSValue runFunction(boolean isConstrutorCall,
                               TSValue ths,
                               TSValue args[])
    {
        return code.execute(isConstrutorCall, ths, args, env);
    }
    
    //@return function call
    public TSValue runFunction(TSValue ths,
                               TSValue args[])
    {
        return code.execute(false, ths, args, env);
    }
    
    public TSBoolean toBoolean() {
        
        return TSBoolean.create(true);
    }
    
    public TSString toStr()
    {
        return TSString.create("function");
    }
    
    public TSNumber toNumber()
    {
        return TSNumber.create(0);
    }

    public TSObject callConstructor(TSValue args[])
    {
        TSObject obj = TSObject.create();
        if(this.hasPrototype())
            obj.put("prototype", this.get("prototype"));
        
        TSValue ret = this.runFunction(false,obj,args);
        if (ret instanceof TSObject)
            return (TSObject)ret;
        
        return obj;
    }
}