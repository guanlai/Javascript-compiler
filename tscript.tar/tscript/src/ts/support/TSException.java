
package ts.support;

public final class TSException extends RuntimeException
{
    /** Single value for exception. */
    private TSValue value = null;
    
    // constructor from string
    public TSException( String str )
    {
        super(str);
        value = TSString.create( str );
    }
    
    // constructor from TSValue
    public TSException( TSValue value )
    {
        this.value = value;
    }
    
    // constructor from number
    public TSException( double value )
    {
        this.value = TSNumber.create(value);
    }
    
    //@return value
    public TSValue getValue()
    {
        return value;
    }
    
    //@return string
    public String getMessage()
    {
        return value.toPrimitive().toStr().getInternal();
    }
}

