
package ts.support;

import ts.Message;

/**
 * The super class for all Tscript values.
 */
public abstract class TSValue
{
    
    public TSValue getValue()
    {
        return this;
    }
    //
    // conversions (section 9)
    //
    
    /** Convert to Primitive. Override only in TSObject.
     *  Otherwise just return "this". Note: type hint is not implemented.
     *
     *  @return the "this" value
     */
    public TSPrimitive toPrimitive()
    {
        return (TSPrimitive) this;
    }
    
    abstract public TSNumber toNumber();
    abstract public TSBoolean toBoolean();
    
    /** Convert to String. Override for all primitive types.
     *  It can't be called toString because of Object.toString.
     *
     *  @return produced TSString value
     */
    public TSString toStr()
    {
        TSPrimitive prim = this.toPrimitive();
        return prim.toStr();
    }
    
    //
    // binary operators (sections 11.5-11.11)
    //
    
    /** Perform a multiply. "this" is the left operand and the right
     *  operand is given by the parameter. Both operands are converted
     *  to Number before the multiply.
     *
     * @param right value to be multiplied
     * @return the result of the multiplication
     */
    public final TSNumber multiply(final TSValue right)
    {
        TSNumber leftValue = this.toNumber();
        TSNumber rightValue = right.toNumber();
        return TSNumber.create(leftValue.getInternal() * rightValue.getInternal());
    }
    
    /** Perform a division. "this" is the left operand and the right
     *  operand is given by the parameter. Both operands are converted
     *  to Number before the multiply.
     *
     * @param right value to be divided
     * @return the result of the division
     */
    public final TSNumber divide(final TSValue right)
    {
        TSNumber leftValue = this.toNumber();
        TSNumber rightValue = right.toNumber();
        return TSNumber.create(leftValue.getInternal() / rightValue.getInternal());
    }
    
    /** Perform an addition. "this" is the left operand and the right
     *  operand is given by the parameter. Both operands are converted
     *  to Number before the addition.
     *
     * @param right value to be added
     * @return the result of the addition
     */
    public final TSPrimitive add(final TSValue right)
    {
        TSPrimitive leftValue = this.toPrimitive();
        TSPrimitive rightValue = right.toPrimitive();
        
        // if one of the operands is a string, then the operation is string
        // concatentation and the other operand must first be converted to
        // a string
        if (leftValue instanceof TSString)
        {
            return TSString.create(((TSString) leftValue).getInternal() +
                                   rightValue.toStr().getInternal());
        }
        else if (rightValue instanceof TSString)
        {
            return TSString.create(leftValue.toStr().getInternal() +
                                   ((TSString) rightValue).getInternal());
        }
        
        // othewise the operation is numeric addition
        return TSNumber.create(leftValue.toNumber().getInternal() +
                               rightValue.toNumber().getInternal());
    }
    
    
    /** Perform an subtraction. "this" is the left operand and the right
     *  operand is given by the parameter. Both operands are converted
     *  to Number before the subtraction.
     *
     * @param right value to be subtracted
     * @return the result of the subtraction
     */
    public final TSPrimitive subtract(final TSValue right)
    {
        TSPrimitive leftValue = this.toPrimitive();
        TSPrimitive rightValue = right.toPrimitive();
        
        // othewise the operation is numeric addition
        return TSNumber.create(leftValue.toNumber().getInternal() -
                               rightValue.toNumber().getInternal());
    }
    
    /** Perform an equality operation. "this" is the left operand
     *  and the right operand is given by the parameter.
     *
     * @param right value to be compared
     * @return the result of the equals
     */
    public final TSPrimitive equals(final TSValue right)
    {
        TSPrimitive leftValue = this.toPrimitive();
        TSPrimitive rightValue = right.toPrimitive();
        // return true for comparison between undefined and null
        if ((leftValue instanceof TSUndefined || leftValue instanceof TSNull)
            && (rightValue instanceof TSUndefined || rightValue instanceof TSNull))
            return TSBoolean.create(true);
        
        // if left and right are string, we use java string compare
        // if two string are equal, java compare return 0, otherwise return 1 or -1
        if (rightValue instanceof TSString && leftValue instanceof TSString)
        {
            String leftSide = leftValue.toStr().getInternal();
            String rightSide = rightValue.toStr().getInternal();
            
            if (leftSide.compareTo(rightSide) != 0 )
                return TSBoolean.create(false);
            else
                return TSBoolean.create(true);
        }
        // if left and right are boolean
        if (leftValue instanceof TSBoolean && rightValue instanceof TSBoolean)
        {
            boolean leftSide = leftValue.toBoolean().getInternal();
            boolean rightSide = rightValue.toBoolean().getInternal();
            
            if (leftSide && rightSide )
                return TSBoolean.create(true);
            else if( leftSide == false && rightSide == false )
                return TSBoolean.create(true);
            else
                return TSBoolean.create(false);
        }
        
        // if left and right are number
        if (rightValue instanceof TSNumber && leftValue instanceof TSNumber)
        {
            double leftSide = leftValue.toNumber().getInternal();
            double rightSide = rightValue.toNumber().getInternal();
            if( leftSide == Double.NaN ||  rightSide == Double.NaN )
                return TSBoolean.create(false);
            if( leftSide == rightSide )
                return TSBoolean.create(true);
            else
                return TSBoolean.create(false);
        }
        
        // if left is number and right is string
        if (leftValue instanceof TSNumber && rightValue instanceof TSString)
            return leftValue.equals( rightValue.toNumber() );
        
        // if left is string and right is number
        if (leftValue instanceof TSString && rightValue instanceof TSNumber)
            return rightValue.equals( leftValue.toNumber() );
        
        // if left is string and right is number
        if (leftValue instanceof TSBoolean )
            return leftValue.toNumber().equals( rightValue );
        
        // if left is string and right is number
        if (rightValue instanceof TSBoolean )
            return rightValue.toNumber().equals( leftValue );
        
        return TSBoolean.create(false);
    }
    
    /** Perform an lessthan operation. "this" is the left operand
     *  and the right operand is given by the parameter.
     *
     * @param right value to be compared
     * @return the result of the comparison
     */
    public final TSPrimitive lessThan(final TSValue right)
    {
        TSPrimitive leftValue = this.toPrimitive();
        TSPrimitive rightValue = right.toPrimitive();
        if (rightValue instanceof TSNumber && leftValue instanceof TSNumber)
        {
            double leftSide = leftValue.toNumber().getInternal();
            double rightSide = rightValue.toNumber().getInternal();
            if( leftSide == Double.NaN ||  rightSide == Double.NaN )
                return TSUndefined.create();
            if( leftSide < rightSide )
                return TSBoolean.create(true);
            else
                return TSBoolean.create(false);
        }
        // if left and right are string, we use java string compare
        // if left side less than right, java compare should return -1
        if (rightValue instanceof TSString && leftValue instanceof TSString)
        {
            String leftSide = leftValue.toStr().getInternal();
            String rightSide = rightValue.toStr().getInternal();
            return TSBoolean.create(leftSide.compareTo(rightSide) == -1);
        }
        // in all other cases, we can convert oprand to number and compare
        double leftSide = leftValue.toNumber().getInternal();
        double rightSide = rightValue.toNumber().getInternal();
        if( leftSide == Double.NaN ||  rightSide == Double.NaN )
            return TSUndefined.create();
        if( leftSide == 0 && rightSide == 0 )
            return TSBoolean.create(false);
        if( leftSide == Double.POSITIVE_INFINITY ||
           rightSide == Double.NEGATIVE_INFINITY )
            return TSBoolean.create(false);
        if( leftSide == Double.NEGATIVE_INFINITY ||
           rightSide == Double.POSITIVE_INFINITY )
            return TSBoolean.create(true);
        if( leftSide < rightSide )
            return TSBoolean.create(true);
        else
            return TSBoolean.create(false);
    }
    
    /** Perform an greater operation. "this" is the left operand
     *  and the right operand is given by the parameter.
     *  use the result of equals and lessThan to get greaterThan
     * @param right value to be compared
     * @return the result of the comparison
     */
    public final TSPrimitive greaterThan(final TSValue right)
    {
        if( this.equals(right).toBoolean().getInternal() ||
           this.lessThan(right) instanceof TSUndefined ||
           this.lessThan(right).toBoolean().getInternal() )
            return TSBoolean.create(false);
        return TSBoolean.create(true);
    }
    
    //
    // unary operators (sections 11.4.7, 11.4.9)
    //
    /** Perform an logicalNot operation. "this" is the right operand.
     * we first convert right operand to boolean then
     * @return the result of logicalNot
     */
    public final TSPrimitive logicalNot()
    {
        TSPrimitive rightValue = this.toPrimitive();
        if( rightValue.toBoolean().getInternal() )
            return TSBoolean.create(false);
        else
            return TSBoolean.create(true);
    }
    
    /** Perform an usubtract operation. "this" is the right operand.
     * we first convert right operand to number then
     * @return the result of usubtract
     */
    public final TSPrimitive usubtract()
    {
        TSPrimitive rightValue = this.toPrimitive();
        double rightSide = rightValue.toNumber().getInternal();
        if( Double.isNaN(rightSide) )
            return TSNumber.create(Double.NaN);
        rightSide *= -1;
        return TSNumber.create(rightSide);
    }
    
    //
    // test for undefined
    //
    
    /** Is this value Undefined? Override only in TSUndefined.
     *
     * @return true or false, is this value the undefined value?
     */
    public boolean isUndefined()
    {
        return false;
    }
    
    public TSValue get( String id )
    {
        return null;
    }

    public void put( String id, TSValue val )
    {
        return;
    }
    
    public TSValue get( TSValue id )
    {
        return null;
    }
    
    public void put( TSValue id, TSValue val )
    {
        return;
    }
    
    //
    // conversions to support optimized code generation
    //
    
    /** Convert a Java String to a TSString. Supports optimized code generation.
     *
     *  @param value Java String to be converted
     *  @return result of conversion
     */
    public static TSValue make(String value)
    {
        return TSString.create(value);
    }
    
    /** Convert a Java double to a TSNumber. Supports optimized code generation.
     *
     *  @param value Java double to be converted
     *  @return result of conversion
     */
    public static TSValue make(double value)
    {
        return TSNumber.create(value);
    }
    
    /** Do nothing, since value already a TSValue. Supports optimized code
     *  generation.
     *
     *  @param value a TSValue already
     *  @return the argument unchanged
     */
    public static TSValue make(TSValue value)
    {
        return value;
    }
    
    public TSObject callConstructor(TSValue args[])
    {
        return TSObject.create();
    }
}

