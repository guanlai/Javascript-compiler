
package ts.support;
import java.util.*;

/*
 * TSEnvironment
 */


public final class TSEnvironment
{
    private final TSEnvironment outerEnvironment;
    private HashMap<String, TSValue> map = new HashMap<String, TSValue>(16);
    private HashMap<String, TSFunctionObject> funMap = new HashMap<String, TSFunctionObject>(16);

    
//    private String catchStr;
//    private boolean doCatch;
    
    //constructor
    private TSEnvironment(final TSEnvironment outer)
    {
        this.outerEnvironment = outer;
    }
    
    //declare name in current environment
    public void declareParameter( String name, TSValue value)
    {
        final boolean dupBind = map.containsKey(name);

        if (!dupBind)
        {
            map.put( name, value );
        }
        else
        {
            System.err.println("duplicate binding!");
        }
    }

    //declare name in current environment
    public void putFunction( String name, TSFunctionObject value)
    {
        final boolean dupBind = funMap.containsKey(name);
        
        if (!dupBind)
        {
            funMap.put( name, value );
        }
        else
        {
            System.err.println("duplicate binding!");
        }
    }
    
    public boolean declared( String name )
    {
        return map.containsKey( name );
    }
    
    public TSValue getValue( String name )
    {
        return map.get( name );
    }
    
    public TSValue getFun( String name )
    {
        return funMap.get( name );
    }
    
    //create declarative environment
    public static TSEnvironment newEnvironment(final TSEnvironment outer)
    {
        return new TSEnvironment( outer );
    }
}