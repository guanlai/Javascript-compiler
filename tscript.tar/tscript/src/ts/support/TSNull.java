
package ts.support;

/**
 * Represents the single Undefined value
 * (<a href="http://www.ecma-international.org/ecma-262/5.1/#sec-8.2">ELS
 * 8.1</a>).
 */
public final class TSNull extends TSPrimitive
{
    /** null has single value of nothing */
    public static final TSNull value = new TSNull();
    
    // hide the constructor
    private TSNull()
    {
    }
    
    /**
     * Create a null value
     *
     * @return the new TSNull
     */
    public static TSNull create() {
        return new TSNull();
    }
    
    /**
     *  @return value in java
     */
    public TSNull getInternal()
    {
        return value;
    }
    
    /** Convert to Number. null is zero.
     *  @return 0.0
     */
    public TSNumber toNumber()
    {
        return TSNumber.create(0.0);
    }
    
    /** Convert to String ("null").
     *  @return "null"
     */
    public TSString toStr()
    {
        return TSString.create("null");
    }
    
    /**Convert to Boolean
     *  @return false
     */
    public TSBoolean toBoolean()
    {
        return TSBoolean.create(false);
    }
}

