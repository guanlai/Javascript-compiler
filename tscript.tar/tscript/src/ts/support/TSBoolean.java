
package ts.support;

/**
 * Represents the Boolean type
 * (<a href="http://www.ecma-international.org/ecma-262/5.1/#sec-8.3">ELS
 * 8.3</a>).
 */
public final class TSBoolean extends TSPrimitive
{
    private final boolean value;
    /** pre-built value for true */
    public static final TSBoolean trueValue = new TSBoolean(true);
    /** pre-built value for false */
    public static final TSBoolean falseValue = new TSBoolean(false);
    
    // use the "create" method instead
    private TSBoolean(final boolean value) {
        this.value = value;
    }
    
    /** return a boolean with the given value.
     *
     *  @param value the Java boolean
     *  @return predefined TSBoolean
     */
    public static TSBoolean create(final boolean value)
    {
        if(value)
            return trueValue;
        else
            return falseValue;
    }
    
    /** return a boolean with a given string.
     *
     *  @param value the Java string
     *  @return predefined TSBoolean
     */
    public static TSBoolean create(final String value)
    {
        if(value.length() > 0)
            return trueValue;
        else
            return falseValue;
    }
    
    /** return a boolean with a given number.
     *
     *  @param value the Java number
     *  @return predefined TSBoolean
     */
    public static TSBoolean create(final double value)
    {
        if(value != 0.0)
            return trueValue;
        else
            return falseValue;
    }
    
    
    /** convert to java boolean
     *  @return java boolean
     */
    public boolean getInternal()
    {
        return value;
    }
    
    /** return the logical not of a boolean
     *  @return java boolean
     */
    public boolean getRInternal()
    {
        return !value;
    }
    
    /** Convert to Number. null is zero.
     *  @return 1.0 or 0.0
     */
    public TSNumber toNumber()
    {
        if (value)
            return TSNumber.create(1.0);
        else
            return TSNumber.create(0.0);
    }
    
    /** Convert to String
     *  @return "true" or "false"
     */
    public TSString toStr()
    {
        if (value)
            return TSString.create("true");
        else
            return TSString.create("false");
    }
    
    /** convert to boolean
     *  @return this
     */
    public TSBoolean toBoolean()
    {
        return this;
    }
}

