package ts.parse;

import ts.Location;
import ts.Message;
import ts.tree.*;

import java.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
/**
 * Provides static methods for building AST nodes.
 */
public class TreeBuilder
{
    /** Build a binary operator.
     *
     *  @param  loc   location in source code (file, line, column).
     *  @param  op    the binary operator.
     *  @param  left  the left subtree.
     *  @param  right the right subtree.
     *  @return tree node for a binary operator.
     *  @see Binop
     */
    public static Expression buildBinaryOperator(final Location loc,
                                                 final Binop op,
                                                 final Expression left,
                                                 final Expression right)
    {
        Message.log("TreeBuilder: Binop " + op.toString());
        return new BinaryOperator(loc, op, left, right);
    }
    
    /** Build a unary operator.
     *
     *  @param  loc   location in source code (file, line, column).
     *  @param  op    the unary operator.
     *  @param  right the right subtree.
     *  @return tree node for a unary operator.
     *  @see Unop
     */
    public static Expression buildUnaryOperator(final Location loc,
                                                final Unop op,
                                                final Expression right)
    {
        Message.log("TreeBuilder: Unop " + op.toString());
        return new UnaryOperator(loc, op, right);
    }
    
    /** Build an expression statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  exp  expression subtree.
     *  @return tree node for an expression statement.
     */
    public static Statement buildExpressionStatement(final Location loc,
                                                     final Expression exp)
    {
        Message.log("TreeBuilder: ExpressionStatement");
        return new ExpressionStatement(loc, exp);
    }
    
    /** Build an identifier expression.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  name name of the identifier.
     *  @return tree node for an identififier.
     */
    public static Expression buildIdentifier(final Location loc,
                                             final String name)
    {
        Message.log("TreeBuilder: Identifier (" + name + ")");
        return new Identifier(loc, name);
    }
    
    /** Build a numeric literal expression. Converts the String for
     *  the value to a double.
     *
     *  @param  loc   location in source code (file, line, column).
     *  @param  value value of the literal as a String.
     *  @return tree node for a numeric literal.
     */
    public static Expression buildNumericLiteral(final Location loc,
                                                 final String value)
    {
        double d = 0.0;
        if( value.startsWith("0x") || value.startsWith("0X") )
        {
            BigInteger number = new BigInteger(value.substring(2), 16);
            d = number.doubleValue();
        }
        else
        {
            try
            {
                d = Double.parseDouble(value);
            }
            catch(NumberFormatException nfe)
            {
                Message.bug(loc, "numeric literal not parsable");
            }
        }
        Message.log("TreeBuilder: NumericLiteral " + d);
        return new NumericLiteral(loc, d);
        
    }
    
    /** Build a print statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  exp  expression subtree.
     *  @return tree node for a print statement.
     */
    public static Statement buildPrintStatement(final Location loc,
                                                final Expression exp)
    {
        Message.log("TreeBuilder: PrintStatement");
        return new PrintStatement(loc, exp);
    }
    
    /** Build the root node of the AST.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  list list of statements for the program.
     *  @return tree node for the root of the AST.
     */
    public static Program buildProgram(final Location loc,
                                       final List<Statement> list)
    {
        Message.log("TreeBuilder: Program");
        return new Program(loc, list);
    }
    
    /** Build a string literal expression.
     *
     *  @param  loc   location in source code (file, line, column).
     *  @param  value value of the literal as a String.
     *  @return tree node for a numeric literal.
     */
    public static Expression buildStringLiteral(final Location loc,
                                                final String value)
    {
        // need to strip off the doublequotes
        String v = value.substring(1, value.length() - 1);
        Message.log("TreeBuilder: StringLiteral " + v);
        return new StringLiteral(loc, v);
    }
    
    /** Build a boolean literal expression.
     *  similar pattern like buildNumericLiteral
     *  @param  loc   location in source code (file, line, column).
     *  @param  value value of the literal as a boolean.
     *  @return tree node for a boolean literal.
     */
    public static Expression buildBooleanLiteral(final Location loc,
                                                 final boolean value)
    {
        Message.log("TreeBuilder: BooleanLiteral " + value);
        return new BooleanLiteral(loc, value);
    }
    
    /** Build a null literal expression.
     *  @param  loc location in source code (file, line, column).
     *  @return tree node for a null literal.
     */
    public static Expression buildNullLiteral(final Location loc)
    {
        Message.log("TreeBuilder: NullLiteral ");
        return new NullLiteral(loc);
    }
    
    /** Build a object literal expression.
     *  similar pattern like buildNumericLiteral
     *  @param  loc   location in source code (file, line, column).
     *  @param  para parameterlist.
     *  @return tree node for a object literal.
     */
    public static Expression buildObjectLiteral(final Location loc,
                                                final HashMap<String, Expression> para)
    {
        Message.log("TreeBuilder: ObjectLiteral " + para);
        return new ObjectLiteral(loc, para);
    }
    
    /** Build a block statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  name name of variable being declared.
     *  @return tree node for a var statement.
     */
    public static Statement buildBlockStatement(final Location loc,
                                                final ArrayList<Statement> name)
    {
        Message.log("TreeBuilder: BlockStatement(" + name + ")");
        return new BlockStatement(loc, name);
    }
    
    /** Build a empty statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @return tree node for a empty statement.
     */
    public static Statement buildEmptyStatement(final Location loc)
    {
        Message.log("TreeBuilder: EmptyStatement");
        return new EmptyStatement(loc);
    }
    
    /** Build a while statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  exp condition of if.
     *  @param  name of statement if condition is true.
     *  @return tree node for a if statement.
     */
    public static Statement buildWhileStatement(final Location loc,
                                                final Expression exp,
                                                final Statement name)
    {
        Message.log("TreeBuilder: WhileStatement(" + exp + name + ")");
        return new WhileStatement(loc, exp, name);
    }
    
    /** Build a if statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  exp condition of if.
     *  @param  name1 if condition is true.
     *  @param  name2 else condition is false.
     *  @return tree node for a if statement.
     */
    public static Statement buildIfStatement(final Location loc,
                                             final Expression exp,
                                             final Statement name1,
                                             final Statement name2)
    {
        Message.log("TreeBuilder: IfStatement(" + exp + name1 + name2 + ")");
        return new IfStatement(loc, exp, name1, name2);
    }
    
    /** Build a break statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @return tree node for a break statement.
     */
    public static Statement buildBreakStatement(final Location loc)
    {
        Message.log("TreeBuilder: BreakStatement()");
        return new BreakStatement(loc);
    }
    
    /** Build a break statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @return tree node for a break statement.
     */
    public static Statement buildContinueStatement(final Location loc)
    {
        Message.log("TreeBuilder: ContinueStatement()");
        return new ContinueStatement(loc);
    }
    
    
    /** Build a if statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  exp value of throw
     *  @return tree node for a throw statement.
     */
    public static Statement buildThrowStatement(final Location loc,
                                                final Expression exp)
    {
        Message.log("TreeBuilder: ThrowStatement(" + exp + ")");
        return new ThrowStatement(loc, exp);
    }
    
    /** Build a finally statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  name block of finally statement
     *  @return tree node for a finally statement.
     */
    public static Statement buildFinallyStatement(final Location loc,
                                                  final Statement name)
    {
        Message.log("TreeBuilder: finallyStatement(" + name + ")");
        return new FinallyStatement(loc, name);
    }
    
    /** Build a catch statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  id the catch parameter
     *  @param  name the statement in catch statement
     *  @return tree node for a finally statement.
     */
    public static Statement buildCatchStatement(final Location loc,
                                                final String id,
                                                final Statement name)
    {
        Message.log("TreeBuilder: CatchStatement(" + id + name + ")");
        return new CatchStatement(loc, id, name);
    }
    
    /** Build a try statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  s1 try statement
     *  @param  s2 catch statement
     *  @param  s3 finally statement
     *  @return tree node for a try statement.
     */
    public static Statement buildTryStatement(final Location loc,
                                              final Statement s1,
                                              final Statement s2,
                                              final Statement s3)
    {
        Message.log("TreeBuilder: TryStatement(" + s1 + s2 + s3 + ")");
        return new TryStatement(loc, s1, s2, s3);
    }
    
    /** Build a var decalaration node.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  name name of variable being declared.
     *  @return tree node for a var statement.
     */
    public static VarDec buildVarDec(final Location loc,
                                     final String name)
    {
        Message.log("TreeBuilder: VarDec (" + name + ")");
        return new VarDec(loc, name);
    }
    
    /** Build a var dec node with three arguments.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  name name of variable being declared.
     *  @param  exp the value to assign
     *  @return tree node for a var statement.
     */
    public static VarDec buildVarDec(final Location loc,
                                     final String name,
                                     final Expression exp)
    {
        Message.log("TreeBuilder: VarDec (" + name + ")");
        return new VarDec(loc, name, exp);
    }
    
    /** Build a "var" statement.
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  name name of variable being declared.
     *  @return tree node for a var statement.
     */
    public static Statement buildVarStatement(final Location loc,
                                              final ArrayList<VarDec> name)
    {
        Message.log("TreeBuilder: VarStatement");
        return new VarStatement(loc, name);
    }
    
    //
    // methods to detect "early" (i.e. semantic) errors
    //
    
    // helper function to detect "reference expected" errors and to
    // mark nodes that denote references as Lvals
    private static boolean producesReference(Node node)
    {
        if (node instanceof Identifier )
        {
            Identifier id = (Identifier) node;
            id.setIsLval();
            return true;
        }
        
        if (node instanceof PropertyAccessor)
        {
            return true;
        }
        
        return false;
    }
    
    /** Used to detect non-references on left-hand-side of assignment and
     *  also to mark identifier nodes as denoting Lvals (location rather
     *  than value).
     *
     *  @param  loc  location in source code (file, line, column).
     *  @param  node tree to be checked.
     */
    public static void checkAssignmentDestination(Location loc, Node node)
    {
        if (!producesReference(node))
        {
            Message.error(loc, "invalid left-hand side in assignment");
        }
    }
    
    /**
     * buildFunctionExpression.
     *
     * @param loc location in source code
     * @param id function name
     * @param fList formal parameters list
     * @param sList statements list
     * @return expression
     */
    public static Expression buildFunctionExpression(final Location loc,
                                                     final String id,
                                                     final ArrayList<String> fList,
                                                     final ArrayList<Statement> sList)
    {
        Message.log("TreeBuilder: FunctionExpression("+ id + fList + sList +")");
        return new FunctionExpression(loc, id, fList, sList);
    }
    
    
    
    /** Build a return statement.
     *
     *  @param  loc  location in source code (file, line, column)
     *  @param  exp  Expression
     *  @return return
     */
    public static Statement buildReturnStatement(final Location loc,
                                                 final Expression exp)
    {
        Message.log("TreeBuilder: ReturnStatement");
        return new ReturnStatement(loc, exp);
    }
    
    /** Build a Arguments.
     *
     *  @param  loc  location in source code (file, line, column)
     *  @param  arg argument list
     *  @return argument
     */
    public static Arguments buildArguments(final Location loc,
                                           final ArrayList<Expression> arg)
    {
        Message.log("TreeBuilder: Arguments");
        return new Arguments(loc, arg);
    }
    
    
    /** Build a FunctionCall.
     *
     *  @param  loc  location in source code (file, line, column)
     *  @param  exp  function express
     *  @param  arg argument list
     *  @return functioncall
     */
    public static Expression buildCallExpression(final Location loc,
                                                 final Expression exp,
                                                 final Arguments arg)
    {
        
        Message.log("TreeBuilder: FunctionCall");
        return new FunctionCall(loc,exp,arg);
    }

    /**
     * buildPropertyAccessor
     *
     * @param loc location of object
     * @param obj host object
     * @param name parameter name
     * @return Expression
     */
    public static Expression buildPropertyAccessor(final Location loc,
                                                   final Expression obj,
                                                   final String name)
    {
        Message.log("TreeBuilder:PropertyAccessor(" + obj + name + ")");
        return new PropertyAccessor(loc, obj, name);
    }
    
    /**
     * buildPropertyAccessor
     *
     * @param loc location of object
     * @param obj host object
     * @param exp parameter name
     * @return Expression
     */
    public static Expression buildPropertyAccessor(final Location loc,
                                                   final Expression obj,
                                                   final Expression exp)
    {
        Message.log("TreeBuilder:PropertyAccessor(" + obj + exp + ")");
        return new PropertyAccessor(loc, obj, exp);
    }

    /**
     * buildNewExpression
     *
     * @param loc location
     * @param exp expression
     * @param args argument list
     * @return Expression
     */
    
    public static Expression buildNewExpression(final Location loc,
                                                final Expression exp,
                                                final Arguments args)
    {
        Message.log("TreeBuilder: NewExpression(exp, args)");
        return new NewExpression(loc, exp, args);
    }
    
    /** Build a ThisExpression.
     *
     *  @param  loc  location in source code (file, line, column)
     *  @return Expression
     */
    public static Expression buildThis(final Location loc)
    {
        Message.log("TreeBuilder: this");
        return new This(loc);
    }
    
    /** build an array literal expression
     *
     *   @param loc location in the source code
     *   @param val elementlist
     *  @return Expression
     */
    public static Expression buildArrayLiteral(final Location loc,
                                               final ArrayList<Expression> val)
    {
        Message.log("TreeBuilder: ArrayLiteral");
        return new ArrayLiteral(loc,val);
    }
}
