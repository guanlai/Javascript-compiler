var y;
y = 1==2;
console.log(y);
