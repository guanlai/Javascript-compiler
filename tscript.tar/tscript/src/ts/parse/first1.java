import ts.Message;
import ts.support.*;
class first {
  public static void main(String args[])
  {
    Message.setLineNumber(1);
    TSValue var_x_0 = TSUndefined.value;
    Message.setLineNumber(2);
    double temp0 = 1.6777215E7;
    TSValue temp2 = TSValue.make(temp0);
    var_x_0 = temp2;
    Message.setLineNumber(6);
    double temp3 = var_x_0;
    System.out.println(TSNumber.create(temp3).toStr().getInternal());
  }
}
