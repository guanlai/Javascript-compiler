var x;
x = 0xffffff;
x = "0xffffff";
var y;
y = true;
console.log(x);
console.log(y);
