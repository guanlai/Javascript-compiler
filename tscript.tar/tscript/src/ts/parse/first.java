import ts.Message;
import ts.support.*;
class first {
  public static void main(String args[])
  {
    Message.setLineNumber(1);
    TSValue var_x_0 = TSUndefined.value;
    Message.setLineNumber(2);
    double temp0 = 1.6777215E7;
    TSValue temp2 = TSValue.make(temp0);
    var_x_0 = temp2;
    Message.setLineNumber(3);
    String temp3 = "0xffffff";
    TSValue temp5 = TSValue.make(temp3);
    var_x_0 = temp5;
    Message.setLineNumber(4);
    TSValue var_y_0 = TSUndefined.value;
    Message.setLineNumber(5);
    TSValue temp6 = TSBoolean.create(true);
    TSValue temp8 = TSValue.make(temp6);
    var_y_0 = temp8;
    Message.setLineNumber(6);
    TSValue temp9 = var_x_0;
    System.out.println(temp9.toPrimitive().toStr().getInternal());
    Message.setLineNumber(7);
    TSValue temp10 = var_y_0;
    System.out.println(temp10.toPrimitive().toStr().getInternal());
  }
}
