
package ts.tree;

/**
 * enum for binary operator names
 *
 */
public enum Binop { ADD, SUBTRACT, ASSIGN, MULTIPLY, DIVIDE, EQUALS, LESS_THAN, GREATER_THAN }

