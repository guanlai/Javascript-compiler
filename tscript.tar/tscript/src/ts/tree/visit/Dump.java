
package ts.tree.visit;

import ts.tree.*;
import ts.tree.type.*;

import java.io.PrintWriter;
import java.util.*;

/**
 * Dump an AST to a stream. Uses prefix order with indentation.
 * <p>
 * Using Object for the type parameter but there is really no return type.
 * <p>
 * The "visit" method is overloaded for each tree node type.
 */
public final class Dump extends TreeVisitorBase<Object>
{
    // where to write the dump to
    private PrintWriter writer;
    
    // current indentation amount
    private int indentation;
    
    // how much to increment the indentation by at each level
    // using an increment of zero would mean no indentation
    private int increment;
    
    /** Initiate the dump even to the left margin and set the increment
     *  indentation amount to two spaces.
     *
     *  @param writer where to write the dump to.
     */
    public Dump(final PrintWriter writer)
    {
        this(writer, 0, 2);
    }
    
    /** Initiate the dump at a specific distance from the left margin and
     *  set the increment indentation amount to a specific value.
     *
     *  @param writer      where to write the dump to.
     *  @param indentation initial indentation amount.
     *  @param increment   increment indentation amount.
     */
    public Dump(final PrintWriter writer,
                final int indentation,
                final int increment)
    {
        this.writer = writer;
        this.indentation = indentation;
        this.increment = increment;
    }
    
    // generate a string of spaces for current indentation level
    private void indent()
    {
        for (int i = 0; i < indentation; i++)
        {
            writer.print(" ");
        }
    }
    
    /** Visit a list of ASTs and dump them in order. Uses a wildcard for
     *  generality: list of Statements, list of Expressions, etc.
     */
    @Override public List<Object> visitEach(final Iterable<?> nodes)
    {
        for (final Object node : nodes)
        {
            visitNode((Tree) node);
        }
        return null;
    }
    
    /** Dump a binary operator. */
    @Override public Object visit(final BinaryOperator binaryOperator)
    {
        indent();
        writer.println(binaryOperator.getOpString() + " (" +
                       binaryOperator.getType() + ") ");
        indentation += increment;
        visitNode(binaryOperator.getLeft());
        visitNode(binaryOperator.getRight());
        indentation -= increment;
        return null;
    }
    
    /** Dump a unary operator. */
    @Override public Object visit(final UnaryOperator unaryOperator)
    {
        indent();
        writer.println(unaryOperator.getOpString() + " (" +
                       unaryOperator.getType() + ") ");
        indentation += increment;
        visitNode(unaryOperator.getRight());
        indentation -= increment;
        return null;
    }
    
    /** Dump an expression statement. */
    @Override public Object visit(final ExpressionStatement expressionStatement)
    {
        indent();
        writer.println("ExpressionStatement");
        indentation += increment;
        visitNode(expressionStatement.getExp());
        indentation -= increment;
        return null;
    }
    
    /** Dump an identifier. */
    @Override public Object visit(final Identifier identifier)
    {
        // get the Type from the declaration tree node (if not null)
        VarDec node = identifier.getVarNode();
        String typeString = null;
        if (node == null)
        {
            typeString = "<var is null>";
        }
        else
        {
            Type type = node.getType();
            if (type == null)
            {
                typeString = "<type is null>";
            }
            else
            {
                typeString = type.toString();
            }
        }
        
        // is it a lval or a rval?
        String valKind = null;
        if (identifier.isLval())
        {
            valKind = "lval";
        }
        else
        {
            valKind = "rval";
        }
        
        // also a "local" type in the identifier node itself
        String locTypeString = null;
        Type locType = identifier.getType();
        if (locType == null)
        {
            locTypeString = "<null>";
        }
        else
        {
            locTypeString = locType.toString();
        }
        
        indent();
        writer.println("Identifier (" + typeString + " " + valKind + ") " +
                       identifier.getName() + " " + locTypeString);
        return null;
    }
    
    /** Dump a numeric literal. */
    @Override public Object visit(final NumericLiteral numericLiteral)
    {
        indent();
        writer.println("NumericLiteral (" + numericLiteral.getType() + ") " +
                       numericLiteral.getValue());
        return null;
    }
    
    /** Dump a object literal. */
    @Override public Object visit(final ObjectLiteral objectLiteral)
    {
        indent();
        writer.println("ObjectLiteral (" + objectLiteral.getType() + ") " +
                       objectLiteral.getPara());
        
        if(objectLiteral.getPara()!= null)
        {
            for( Map.Entry<String, Expression> entry : objectLiteral.getPara().entrySet() )
            {
                visitNode( entry.getValue() );
            }
        }
        return null;
    }
    
    /** Dump a boolean literal. */
    @Override public Object visit(final BooleanLiteral booleanLiteral)
    {
        indent();
        writer.println("BooleanLiteral (" + booleanLiteral.getType() + ") " +
                       booleanLiteral.getValue());
        return null;
    }
    
    /** Dump a null literal. */
    @Override public Object visit(final NullLiteral nullLiteral)
    {
        indent();
        writer.println("NullLiteral (" + nullLiteral.getType() + ") " +
                       nullLiteral.getValue());
        return null;
    }
    
    /** Dump a print statement. */
    @Override public Object visit(final PrintStatement printStatement)
    {
        indent();
        writer.println("PrintStatement");
        indentation += increment;
        visitNode(printStatement.getExp());
        indentation -= increment;
        return null;
    }
    
    /** Dump a program. */
    @Override public Object visit(final Program program)
    {
        indent();
        writer.println("Program");
        indentation += increment;
        visitEach(program.getList());
        indentation -= increment;
        return null;
    }
    
    /** Dump a string literal. */
    @Override public Object visit(final StringLiteral stringLiteral)
    {
        indent();
        writer.println("StringLiteral (" + stringLiteral.getType() + ") " +
                       stringLiteral.getValue());
        return null;
    }
    
    /** Dump a var dec. */
    @Override public Object visit(final VarDec varDec)
    {
        Type type = varDec.getType();
        String typeStr = null;
        if (type == null)
        {
            typeStr = "<null>";
        }
        else
        {
            typeStr = type.toString();
        }
        String capturedStr = null;
        if (varDec.isCaptured())
        {
            capturedStr = "captured";
        }
        else
        {
            capturedStr = "not-captured";
        }
        String redundantStr = null;
        if (varDec.isCaptured())
        {
            redundantStr = "redundant";
        }
        else
        {
            redundantStr = "not-redundant";
        }
        indent();
        writer.println("Var (" +
                       typeStr + " " +
                       varDec.getFunctionDepth() + " " +
                       varDec.getTempName() + " " +
                       capturedStr + " " +
                       redundantStr + ") " +
                       varDec.getName());
        return null;
    }
    
    
    /** Dump a var statement. */
    @Override public Object visit(final VarStatement varStatement)
    {
        visitEach(varStatement.getList());
        return null;
    }
    
    /** Dump a blockstatement. */
    @Override public Object visit(final BlockStatement blockStatement)
    {
        indent();
        writer.println("BlockStatement");
        return null;
    }
    
    /** Dump an emptystatement. */
    @Override public Object visit(final EmptyStatement emptyStatement)
    {
        indent();
        writer.println("EmptyStatement");
        return null;
    }
    
    /** Dump an whilestatement. */
    public Object visit(final WhileStatement whileStatement)
    {
        indent();
        writer.println("WhileStatement");
        indentation += increment;
        visitNode(whileStatement.getExp());
        visitNode(whileStatement.getStat());
        indentation -= increment;
        return null;
    }
    
    /** Dump an ifstatement. */
    public Object visit(final IfStatement ifStatement)
    {
        indent();
        writer.println("IfStatement");
        indentation += increment;
        visitNode(ifStatement.getExp());
        visitNode(ifStatement.getThenStat());
        if (ifStatement.getElseStat()!=null)
            visitNode(ifStatement.getElseStat());
        indentation -= increment;
        return null;
    }
    
    /** Dump an BreakStatement. */
    public Object visit(final BreakStatement breakStatement)
    {
        indent();
        writer.println("BreakStatement");
        return null;
    }
    
    /** Dump an ContinueStatement. */
    public Object visit(final ContinueStatement continueStatement)
    {
        indent();
        writer.println("ContinueStatement");
        return null;
    }
    
    /** Dump an ThrowStatement. */
    public Object visit(final ThrowStatement throwStatement)
    {
        indent();
        writer.println("ThrowStatement");
        indentation += increment;
        visitNode(throwStatement.getExp());
        indentation = indentation - increment;
        return null;
    }
    
    /** Dump an TryStatement. */
    public Object visit(final TryStatement tryStatement)
    {
        indent();
        writer.println("TryStatement");
        
        int temp = indentation;
        final Statement s1 = tryStatement.getTryStat();
        final Statement s2 = tryStatement.getCatchStat();
        final Statement s3 = tryStatement.getFinalStat();
        
        
        if (s1 != null)
        {
            indentation += increment;
            visitNode(s1);
        }
        
        if (s2 != null)
        {
            indentation += increment;
            visitNode(s2);
        }
        
        if (s3 != null)
        {
            indentation += increment;
            visitNode(s3);
        }
        
        indentation = temp;
        return null;
    }
    
    /** Dump an CatchStatement. */
    public Object visit(final CatchStatement catchStatement)
    {
        indent();
        writer.println("CatchStatement identifier " + catchStatement.getId());
        indentation += increment;
        visitNode(catchStatement.getCatchStat());
        indentation -= indentation;
        return null;
    }
    
    /** Dump an FinallyStatement. */
    public Object visit(final FinallyStatement finallyStatement)
    {
        indent();
        writer.println("FinallyStatement");
        indentation += increment;
        visitNode(finallyStatement.getFinalStat());
        indentation = indentation - increment;
        return null;
    }
    
    /** Dump an Arguments list. */
    public Object visit(final Arguments arguments)
    {
        indent();
        writer.println("Arguments");
        indentation += increment;
        visitEach(arguments.getList());
        indentation -= increment;
        return null;
    }
    
    /** Dump a function call. */
    public Object visit(final FunctionCall functionCall)
    {
        indent();
        writer.println("FunctionCall");
        indentation += increment;
        visitNode(functionCall.getExp());
        if(functionCall.getArg() != null )
            visitNode(functionCall.getArg());
        indentation -= increment;
        return null;
    }
    
    /** Dump a return statement */
    public Object visit(final ReturnStatement returnStatement)
    {
        indent();
        writer.println("ReturnStatement");
        indentation += increment;
        if(returnStatement.getExp() != null )
            visitNode(returnStatement.getExp());
        indentation -= increment;
        return null;
    }
    
    /** Dump a function expression*/
    public Object visit(final FunctionExpression functionExpression)
    {
        indent();
        writer.println("FunctionExpression");
        indentation += increment;
        writer.println(functionExpression.getName());
        writer.println(functionExpression.getPara());
        if(functionExpression.getBody() != null)
        {
            for( Statement s: functionExpression.getBody() )
                visitNode(s);
        }
        indentation -= increment;
        return null;
    }
    
    /** Dump a PropertyAccessor expression*/
    public Object visit(final PropertyAccessor propertyAccessor)
    {
        indent();
        writer.println("PropertyAccessorExpression");
        indentation += increment;
        if((propertyAccessor.getExp()) != null )
        {
            visitNode(propertyAccessor.getExp());
        }
        if((propertyAccessor.getParam()) != null )
        {
            visitNode(propertyAccessor.getParam());
        }
        else
        {
            writer.println(propertyAccessor.getId());
        }
        indentation -= increment;
        return null;
    }
    
    /** Dump a NewExpression expression*/
    public Object visit(final NewExpression newExpression)
    {
        indent();
        writer.println("NewExpression");
        indentation += increment;
        visitNode(newExpression.getExp());
        if(newExpression.getArg() != null )
            visitNode(newExpression.getArg());
        indentation -= increment;
        return null;
    }
    
    /** Dump a NewExpression expression*/
    public Object visit(This ths)
    {
        indent();
        writer.println("this");
        return null;
    }
    
    /** Dump an array literal. */
    @Override public Object visit(final ArrayLiteral arrayLiteral)
    {
        indent();
        writer.println("ArrayLiteral");
        if(arrayLiteral.getList()!= null)
        {
            indentation += increment;
            visitEach(arrayLiteral.getList());
            indentation -= increment;
        }
        return null;
    }
}

