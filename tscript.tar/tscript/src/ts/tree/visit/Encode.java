/**
 * Traverse an AST to generate Java code.
 *
 */

package ts.tree.visit;

import ts.Message;
import ts.Main;
import ts.tree.*;
import ts.tree.type.*;

import java.util.*;

/**
 * Does a traversal of the AST to generate Java code to execute the program
 * represented by the AST.
 * <p>
 * Uses a static nested class, Encode.ReturnValue, for the type parameter.
 * This class contains two String fields: one for the temporary variable
 * containing the result of executing code for an AST node; one for the
 * code generated for the AST node.
 * <p>
 * The "visit" method is overloaded for each tree node type.
 */
public final class Encode extends TreeVisitorBase<Encode.ReturnValue>
{
    private Stack<Integer> loopDepth = new Stack<Integer>();
    private Stack<String> context = new Stack<String>();
    private Stack< Stack<String> > contextCtrl = new Stack< Stack<String> >();
    private Stack<Boolean> inCatch = new Stack<Boolean>();
    private Stack<String> catchStr = new Stack<String>();
    private List<Encode.ReturnValue> funcList = new ArrayList<Encode.ReturnValue>();
    private ArrayList<String> argTunk = new ArrayList<String>();
    
    private int loop = 0;
    private int EnvNum = 0;
    private int funcDepth = 0;
    private int funNum = 0;
    
    private String currentEnv = null;
    private String outerMostEvn = null;
    private String currentCatch = null;
    private String thisBind = "thisBind";

    
    public List<Encode.ReturnValue> getFuncList()
    {
        return funcList;
    }
    
    private String getEnv()
    {
        String val = "Environment" + EnvNum;
        EnvNum += 1;
        return val;
    }
    
    private void enterNewEnv(String env )
    {
        
        context.push(env);
        currentEnv = context.top();
    }
    
    private void exitNewEnv()
    {
        context.pop();
        currentEnv = context.top();
    }
    
    //update info when get into new context
    private void enterNewContext()
    {
        //new context
        Stack<String> newContext = new Stack<String>();
        context = newContext;
        contextCtrl.push(newContext);
        //setup environment
        context.push( getEnv() );
        currentEnv = context.top();
        outerMostEvn = context.bot();
        
        loop = 0;
        loopDepth.push(loop);
    }
    
    //clean up when get out of current context
    private void exitNewContext()
    {
        
        //pop the execontext form the stack
        
        contextCtrl.pop();
        
        //check if we exit the main
        if(!contextCtrl.isEmpty()){
            context = contextCtrl.top();
            currentEnv = context.top();
            outerMostEvn = context.bot();
        }
        
        loopDepth.pop();
        if(!loopDepth.isEmpty())
            loop = loopDepth.top();
        
    }
    
    
    /**
     * Static nested class to represent the return value of the Encode methods.
     * Contains the following fields:
     * <ul>
     * <li> a String containing the result operand name
     * <li> a String containing the code to be generated
     * </ul>
     * Only expressions generate results, so the result operand name
     * will be null in other cases, such as statements.
     */
    static public class ReturnValue
    {
        /** the result operand name. */
        public String result;
        
        /** the code to be generated. */
        public String code;
        
        // initialize both fields
        private ReturnValue()
        {
            result = null;
            code = null;
        }
        
        /** Construct an encode return value for non-expressions.
         *
         *  @param code the code to be placed in the return value
         */
        public ReturnValue(final String code)
        {
            this();
            this.code = code;
        }
        
        /** Construct an encode return value for most expressions.
         *
         *  @param result the result operand code.
         *  @param code the code to be generated.
         */
        public ReturnValue(final String result, final String code)
        {
            this();
            this.result = result;
            this.code = code;
        }
    }
    
    // simple counter for expression temps
    private int nextTemp = 0;
    
    /** Initiate an encode traversal with the output indented two spaces and
     *  the increment indentation amount set to two spaces.
     */
    public Encode()
    {
        this(2, 2);
    }
    
    // initial indentation value
    private final int initialIndentation;
    
    // current indentation amount
    private int indentation;
    
    // how much to increment the indentation by at each level
    // using an increment of zero would mean no indentation
    private final int increment;
    
    // increase indentation by one level
    private void increaseIndentation()
    {
        indentation += increment;
    }
    
    // decrease indentation by one level
    private void decreaseIndentation()
    {
        indentation -= increment;
    }
    
    /** Initiate an encode traversal with the output indented by a specific
     *  amount and the increment indentation amount set to a specific amount.
     *
     *  @param initialIndentation the initial indentation amount.
     *  @param increment the increment indentation amount.
     */
    public Encode(final int initialIndentation, final int increment)
    {
        // setup indentation
        this.initialIndentation = initialIndentation;
        this.indentation = initialIndentation;
        this.increment = increment;
    }
    
    // generate a string of spaces for current indentation level
    private String indent()
    {
        String ret = "";
        for (int i = 0; i < indentation; i++)
        {
            ret += " ";
        }
        return ret;
    }
    
    /** Generate the main method signature.
     *  @return the main method signature.
     */
    public String mainMethodSignature()
    {
        return "public static void main(String args[])";
    }
    
    /** Generate and return prologue code for the main method body.
     *
     *  @param filename source filename.
     *  @return the prologue code for the main method body.
     */
    public String mainPrologue(String filename)
    {
        String ret = "";
        ret += indent() + "{\n";
        increaseIndentation();
        ret += indent() + "try {\n";
        enterNewContext();
        ret += indent() + "TSEnvironment " + currentEnv +
        " = TSEnvironment.newEnvironment(null);\n";
        
        return ret;
    }
    
    /** Generate and return epilogue code for the main method body.
     *
     *  @return the epilogue code for the main method body.
     */
    public String mainEpilogue()
    {
        decreaseIndentation();
        String ret = "";
        ret += indent() + "} catch (TSException tse) {\n";
        increaseIndentation();
        ret += indent() + "Message.executionError(tse.getMessage());\n";
        decreaseIndentation();
        ret += indent()+"}\n";
        ret += indent() + "}";
        exitNewContext();
        
        return ret;
    }
    
    //java stack is not as good as C++, define a linkedlist based stack class
    private class Stack<T>
    {
        private LinkedList<T> data = new LinkedList<T>();
        public T top() {return data.getFirst();}
        public T bot() {return data.getLast();}
        public T pop() {return data.removeFirst();}
        public void push(T v) {data.addFirst(v);}
        public void settop(T value) {data.set(0,value);}
        public boolean isEmpty() {return data.isEmpty();}
        public int size() {return data.size();}
    }
    
    // return string for name of next expression temp
    private String getTemp()
    {
        String ret = "temp" + nextTemp;
        nextTemp += 1;
        return ret;
    }
    
    // given AST Type, return for the matching Java type
    private String getJavaType(Type type)
    {
        if (type.isNumberType())
        {
            return "double";
        }
        else if (type.isStringType())
        {
            return "String";
        }
        return "TSValue";
    }
    
    /** Visit a list of ASTs and generate code for each of them in order.
     *  Uses a wildcard for generality: list of Statements, list of Expressions,
     *  etc. Returns a list containing the generated code for each element
     *  of the input list.
     */
    @Override public List<Encode.ReturnValue> visitEach(final Iterable<?> nodes)
    {
        List<Encode.ReturnValue> ret = new ArrayList<Encode.ReturnValue>();
        for (final Object node : nodes)
        {
            ret.add(visitNode((Tree) node));
        }
        return ret;
    }
    
    /** Generate and return code for a binary operator. */
    @Override public Encode.ReturnValue visit(final BinaryOperator binaryOperator)
    {
        // try to do optimized code generation first
        final Binop op = binaryOperator.getOp();
        final Type type = binaryOperator.getType();
        final String opString = binaryOperator.getOpString();
        
        // generate code to evaluate left subtree
        Expression left = binaryOperator.getLeft();
        Encode.ReturnValue leftReturnValue = null;
        String code = "";
        String leftResult ="";
        if( left instanceof PropertyAccessor && op == Binop.ASSIGN )
        {
            PropertyAccessor left1 = (PropertyAccessor ) left;
            leftReturnValue = visitNode(left1.getExp());
            code = leftReturnValue.code;
            leftResult = leftReturnValue.result;
        }
        else if(left instanceof Identifier && op == Binop.ASSIGN )
        {
            leftResult = ((Identifier) left).getName();
        }
        else
        {
            leftReturnValue = visitNode(left);
            code = leftReturnValue.code;
            leftResult = leftReturnValue.result;
        }

        // generate code to evaluate right subtree
        Expression right = binaryOperator.getRight();
        Encode.ReturnValue rightReturnValue = visitNode(right);
        code += rightReturnValue.code;
        String rightResult = rightReturnValue.result;
        
        //
        // now generate code to do the binary operator itself
        //
        
        // name of Java variable to receive the result value
        String result = getTemp();
        

        switch (op) {
                
            case ADD:
                
                // if result type is Number then both operands are Numbers
                // so just perform Java add and leave result as a Java double
                if (type.isNumberType())
                {
                    code += indent() + "double " + result + " = " + leftResult +
                    " + " + rightResult + ";\n";
                    return new Encode.ReturnValue(result, code);
                }
                
                // if result type is String, then one of the operands is a String
                // but the other might not be a String, and might even be Unknown
                if (type.isStringType())
                {
                    // if the type of the subtree is known now to be Number, then
                    // need to convert it to a TSString in order to get the
                    // Javascript conversion of Number to String because the
                    // conversion is different than the Java conversion of double
                    // to String.
                    if (left.getType().isNumberType())
                    {
                        leftResult = "TSNumber.create(" + leftResult + ")";
                    }
                    if (right.getType().isNumberType())
                    {
                        rightResult = "TSNumber.create(" + rightResult + ")";
                    }
                    
                    // if the type of a subtree is not known now to be String, then
                    // need to make sure it will be converted to String if necessary
                    if (!left.getType().isStringType())
                    {
                        leftResult += ".toStr().getInternal()";
                    }
                    if (!right.getType().isStringType())
                    {
                        rightResult += ".toStr().getInternal()";
                    }
                    
                    // generate code to do Java string concatentation
                    code += indent() + "String " + result + " = " + leftResult +
                    " + " + rightResult + ";\n";
                    return new Encode.ReturnValue(result, code);
                }
                
                // otherwise need to do unoptimized code generation
                break;
                
            case SUBTRACT:
                // if result type is Number then both operands are Numbers
                // so just perform Java subtract and leave result as a Java double
                if (type.isNumberType())
                {
                    code += indent() + "double " + result + " = TSValue.make(" + leftResult +
                    ").toPrimitive().toNumber().getInternal() - TSValue.make(" + rightResult + ").toPrimitive().toNumber().getInternal();\n";
                    return new Encode.ReturnValue(result, code);
                }
                break;
                
            case ASSIGN:
                // to be safe, always use TSValue
                String rightResult2 = getTemp();
                code += indent() + "TSValue " + rightResult2 +
                " = TSValue.make(" + rightResult + ");\n";
                
                if( left instanceof PropertyAccessor )
                {
                    PropertyAccessor left1 = (PropertyAccessor ) left;
                    
                    String id = "";
                    if(left1.getId() != null)
                    {
                        id = left1.getId();
                        code += indent() + leftResult + ".put(\""+ id + "\"," + rightResult2 + ");\n";
                    }
                    else
                    {
                        final Encode.ReturnValue exp1 = visitNode(left1.getParam());
                        code += exp1.code;
                        id = exp1.result;
                        String idStr = getTemp();
                        code += indent() + "String " + idStr + " = TSValue.make("+id+").toPrimitive().toStr().getInternal();\n";
                        code += indent() + leftResult + ".put("+ idStr + "," + rightResult2 + ");\n";
                    }
                    
                }
                else if(left instanceof Identifier)
                {
                    code += indent() + "TSObject.globalObject.put2(\""+leftResult+"\", "+ rightResult2+");\n";
                }
                else
                {
                    code += indent() + leftResult + " = " + rightResult2 + ";\n";
                }
                return new Encode.ReturnValue(rightResult, code);
                
            case MULTIPLY:
                
                // if the type of a subtree is not known now to be Number, then
                // need to make sure it will be converted to Number if necessary
                if (!left.getType().isNumberType())
                {
                    leftResult = "TSValue.make(" + leftResult +
                    ").toNumber().getInternal()";
                }
                if (!right.getType().isNumberType())
                {
                    rightResult = "TSValue.make(" + rightResult +
                    ").toNumber().getInternal()";
                }
                // now generate a Java multiply
                code += indent() + "double " + result + " = " + leftResult +
                " * " + rightResult + ";\n";
                return new Encode.ReturnValue(result, code);
                
            case DIVIDE:
                
                // if the type of a subtree is not known now to be Number, then
                // need to make sure it will be converted to Number if necessary
                if (!left.getType().isNumberType())
                {
                    leftResult = "TSValue.make(" + leftResult +
                    ").toNumber().getInternal()";
                }
                if (!right.getType().isNumberType())
                {
                    rightResult = "TSValue.make(" + rightResult +
                    ").toNumber().getInternal()";
                }
                
                // now generate a Java divide
                code += indent() + "double " + result + " = " + leftResult +
                " / " + rightResult + ";\n";
                return new Encode.ReturnValue(result, code);
                
            case EQUALS:
                // use default case, and optimize in TSValue class
                break;
                
            case LESS_THAN:
                // use default case, and optimize in TSValue class
                break;
                
            case GREATER_THAN:
                // use default case, and optimize in TSValue class
                break;
                
            default:
                Message.bug("unexpected operator: " + opString);
        }
        
        //
        // if control reaches here then do unoptimized code generation
        //
        
        // one of the subtrees might be a Java value at run-time so
        // need to generate code that will convert it to a TSValue if necessary
        String methodName = getMethodNameForBinaryOperator(binaryOperator);
        code += indent() + "TSValue " + result + " = TSValue.make(" + leftResult +
        ")." + methodName + "(TSValue.make(" + rightResult + "));\n";
        
        return new Encode.ReturnValue(result, code);
    }
    
    // support routine for handling binary operators
    private static String getMethodNameForBinaryOperator(final BinaryOperator opNode)
    {
        final Binop op = opNode.getOp();
        
        switch (op) {
            case ADD:
                return "add";
            case SUBTRACT:
                return "subtract";
            case MULTIPLY:
                return "multiply";
            case DIVIDE:
                return "divide";
            case EQUALS:
                return "equals";
            case LESS_THAN:
                return "lessThan";
            case GREATER_THAN:
                return "greaterThan";
            default:
                Message.bug("unexpected operator: " + opNode.getOpString());
        }
        // cannot reach
        return null;
    }
    
    /** Generate and return code for a unary operator. */
    @Override public Encode.ReturnValue visit(final UnaryOperator unaryOperator)
    {
        // generate code to evaluate right subtree
        Expression right = unaryOperator.getRight();
        Encode.ReturnValue rightReturnValue = visitNode(right);
        String code = rightReturnValue.code;
        String rightResult = rightReturnValue.result;
        
        //
        // now generate code to do the unary operator itself
        //
        
        // name of Java variable to receive the result value
        String result = getTemp();
        
        // try to do optimized code generation first
        final Unop op = unaryOperator.getOp();
        final Type type = unaryOperator.getType();
        final String opString = unaryOperator.getOpString();
        switch (op) {
            case USUBTRACT:
                // use default case, and optimize in TSValue class
                break;
                
            case LOGICAL_NOT:
                // use default case, and optimize in TSValue class
                break;
            default:
                Message.bug("unexpected operator: " + opString);
        }
        
        //
        // if control reaches here then do unoptimized code generation
        //
        
        // one of the subtrees might be a Java value at run-time so
        // need to generate code that will convert it to a TSValue if necessary
        String methodName = getMethodNameForUnaryOperator(unaryOperator);
        code += indent() + "TSValue " + result + " = TSValue.make(" + rightResult +
        ")." + methodName + "(" + ");\n";
        
        return new Encode.ReturnValue(result, code);
    }
    
    // support routine for handling Unary operators
    private static String getMethodNameForUnaryOperator(final UnaryOperator opNode)
    {
        final Unop op = opNode.getOp();
        
        switch (op) {
            case USUBTRACT:
                return "usubtract";
            case LOGICAL_NOT:
                return "logicalNot";
            default:
                Message.bug("unexpected operator: " + opNode.getOpString());
        }
        // cannot reach
        return null;
    }
    
    /** Generate and return code for an expression statement. */
    @Override public Encode.ReturnValue visit(final ExpressionStatement
                                              expressionStatement)
    {
        Encode.ReturnValue exp = visitNode(expressionStatement.getExp());
        String code = indent() + "Message.setLineNumber(" +
        expressionStatement.getLineNumber() + ");\n";
        code += exp.code;
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for an identifier. */
    @Override public Encode.ReturnValue visit(final Identifier identifier)
    {
        String result = null;
        String code = "";
        
        if( EnvNum > 1 && inCatch.size() > 0 && inCatch.top()
           && identifier.getName().equals(catchStr.top()) )
        {
            result = getTemp();
            code = indent() + "TSValue " + result + " = " + currentEnv +
            ".getValue(\"" + identifier.getName() + "\");\n";
            return new Encode.ReturnValue(result, code);
        }
        
        // info about the variable is stored in the VarDec node
        // that declared it
        VarDec varNode = identifier.getVarNode();
        
        // if there is no link back to the Var declaration then
        // the identifier is not declared
        if (varNode == null)
        {
            //            if( !argTunk.isEmpty() && argTunk.contains(identifier.getName()) )
            //            {
            //                result = getTemp();
            //                code += indent() + "TSValue " + result;
            //                code += " = " + currentEnv + ".getValue("+identifier.getName()+");\n";
            //                return new Encode.ReturnValue(result, code);
            //            }
            
            // if identifier is an lval then eventually we will need to insert
            // a property into the global object, but since we are not yet
            // implementing the global object, we need to treat this case as
            // an error, same as rval
//            if( funcDepth == 0 && identifier.isLval())
//            {
//                code += indent() + "TSObject.globalObject.put2(\""+ identifier.getName() +"\", TSUndefined.value);\n";
//            }
//            else
//            {
            if( funcDepth == 0 )
            {
                result = getTemp();
                code += indent() + "TSValue "+ result + " = TSObject.globalObject.get2(\""+ identifier.getName() +"\");\n";
            }
            else
            {
                code += indent() + "Message.executionError(\"undefined identifier: " +
                identifier.getName() + "\");\n";
                
                // so that the Java code will compile, need to build a dummy result
                result = getTemp();
                code += indent() + "TSValue " + result + " = TSUndefined.value;\n";
            }
        }
        // otherwise identifier is declared
        else
        {
            String codegenName = "";
            if(funcDepth == 0 )
                codegenName = varNode.getName();
            else
                codegenName = varNode.getTempName();

            Type type = varNode.getType();
            
            // does the identifier denote the address of a variable or its value?
            if (identifier.isLval())
            {
                // just need the variable's address (so no code needs to be generated)
                result = codegenName;
            }
            else
            {
                // need to deref the variable to get its value
                String jType = getJavaType(type);
                result = getTemp();
                if( funcDepth == 0 )
                    code += indent() + "TSValue " + result + " = TSObject.globalObject.get2(\"" + codegenName + "\");\n";
                else
                    code += indent() + jType + " " + result + " = " + codegenName + ";\n";
            }
        }

        return new Encode.ReturnValue(result, code);
    }
    
    /** Generate and return code for a numeric literal. */
    @Override public Encode.ReturnValue visit(final NumericLiteral numericLiteral)
    {
        String result = getTemp();
        String code = indent() + "double " + result + " = " +
        numericLiteral.getValue() + ";\n";
        
        return new Encode.ReturnValue(result, code);
    }
    
    /** Generate and return code for a boolean literal. */
    @Override public Encode.ReturnValue visit(final BooleanLiteral booleanLiteral)
    {
        String result = getTemp();
        String code = indent() + "TSValue " + result + " = " +
        "TSBoolean.create(" + booleanLiteral.getValue() + ");\n";
        
        return new Encode.ReturnValue(result, code);
    }
    
    /** Generate and return code for a null literal. */
    @Override public Encode.ReturnValue visit(final NullLiteral nullLiteral)
    {
        String result = getTemp();
        String code = indent() + "TSValue " + result + " = " +
        "TSNull.create();\n";
        
        return new Encode.ReturnValue(result, code);
    }
    
    /** Generate and return code for a objectLiteral. */
    public Encode.ReturnValue visit(final ObjectLiteral objectLiteral)
    {
        String result = getTemp();
        String code = indent() + "TSObject " + result + " = " +
        "TSObject.create(null);\n";
        if(objectLiteral.getPara()!= null)
        {
            for( Map.Entry<String, Expression> entry : objectLiteral.getPara().entrySet() )
            {
                Encode.ReturnValue exp = visitNode(entry.getValue());
                code += exp.code;
                code += indent() + result + ".put(\""+entry.getKey()+"\",TSValue.make("+exp.result+"));\n";
            }
        }
        return new Encode.ReturnValue(result, code);
    }
    
    /** Generate and return code for an arrayLiteral. */
    public Encode.ReturnValue visit(final ArrayLiteral arrayLiteral)
    {
        String code = "";
        
        String array = getTemp();
        code += indent() + "TSArray " + array + " = TSArray.create();\n";
        
        if(arrayLiteral.getList()==null)
        {
            code += indent() + array + ".put(\"length\",TSNumber.create(0.));\n";
        }
        else
        {
            
            List<Encode.ReturnValue> values = visitEach(arrayLiteral.getList());
            for(Encode.ReturnValue elem : values)
            {
                code += elem.code;
                code += indent() + array + ".push(TSValue.make("+ elem.result +"));\n";
            }
        }
        
        return new Encode.ReturnValue(array,code);
    }
    
    /** Generate and return code for a print statement. */
    @Override public Encode.ReturnValue visit(final PrintStatement printStatement)
    {
        Type type = printStatement.getExp().getType();
        Encode.ReturnValue exp = visitNode(printStatement.getExp());
        String code = indent() + "Message.setLineNumber(" +
        printStatement.getLineNumber() + ");\n";
        code += exp.code;
        if (type.isNumberType())
        {
            // need to apply Javascript Number -> String conversion
            code += indent() + "System.out.println(TSNumber.create(" + exp.result +
            ").toStr().getInternal());\n";
        }
        else if (type.isStringType())
        {
            code += indent() + "System.out.println(" + exp.result + ");\n";
        }
        else
        {
            code += indent() + "System.out.println(" + exp.result +
            ".toPrimitive().toStr().getInternal());\n";
        }
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a program. */
    @Override public Encode.ReturnValue visit(final Program program)
    {
        String code = "";

        code += indent() + "TSValue " + thisBind + " = TSObject.globalObject;\n";
        //Map<String, Deque<VarDec>> table = program.getTable();
        for( VarDec var : program.getTable() )
        {
            if( var != null )
            {
                String temp = var.getName();
                code += indent() + "TSObject.globalObject.put2(\""+ temp +"\", TSUndefined.value);\n";
                //code += indent() + "TSValue " + temp + " = TSUndefined.value;\n";
            }
        }
        
        for (Encode.ReturnValue value : visitEach(program.getList()))
        {
            code += value.code;
        }
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a string literal. */
    //at here, we take action to process the double quote symble in string
    //wonder if it is better to handle it in print statement so that we do not
    //modify user input data untill output
    @Override public Encode.ReturnValue visit(final StringLiteral stringLiteral)
    {
        String temp = stringLiteral.getValue().replace("\"", "" + '\\' + "\"");
        String result = getTemp();
        String code = indent() + "String " + result + " = \"" + temp + "\";\n";
        
        return new Encode.ReturnValue(result, code);
    }
    
    @Override public Encode.ReturnValue visit(final VarDec varDec)
    {
        // if this var node is redundant, then skip it
        if (varDec.isRedundant())
        {
            return new Encode.ReturnValue("");
        }
        String code = indent() + "Message.setLineNumber(" +
        varDec.getLineNumber() + ");\n";
        // if this variable was never used, then Type will be null.
        // in that case treat as if the type is unknown
        String varName = varDec.getTempName();
        String id = varDec.getName();
        Expression exp = varDec.getValue();
        
        //code += indent() + "TSValue " + varName + " = TSUndefined.value;\n";
        
        if (exp == null)
            return new Encode.ReturnValue(code);
        // for those who has assignment expression
        
        Encode.ReturnValue expReturn = visitNode(exp);
        code += expReturn.code;
        String expResult = expReturn.result;
        
        if(funcDepth == 0)
        {
            code += indent() + "TSObject.globalObject.put2(\""+id+"\", TSvalue.make(" + expResult + "));\n";
        }
        else
        {
            // need to generate code to make a TSValue and then assign
            String rightResult2 = getTemp();
            code += indent() + "TSValue " + rightResult2 +
            " = TSValue.make(" + expResult + ");\n";
            code += indent() + varName + " = " + rightResult2 + ";\n";
        }
        return new Encode.ReturnValue(code);

    }
    
    /** Generate and return code for a var statement. */
    @Override public Encode.ReturnValue visit(final VarStatement varStatement)
    {
        String code = "";
        for (Encode.ReturnValue value : visitEach(varStatement.getList()))
        {
            code += value.code;
        }
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a blockstatement. */
    @Override public Encode.ReturnValue visit(final BlockStatement blockStatement)
    {
        //String code = "" + indent()+ "Message.setLineNumber(" +
        //  blockStatement.getLineNumber() + ");\n";
        String code = "" + indent();
        if(blockStatement.getValue() != null)
            for (Statement s : blockStatement.getValue() )
            {
                code += visitNode(s).code.replace("\n", "\n"+indent());
            }
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a emptystatement. */
    public Encode.ReturnValue visit(final EmptyStatement emptyStatement)
    {
        return new Encode.ReturnValue(indent()+";\n");
    }
    
    /** Generate and return code for a whilestatement. */
    public Encode.ReturnValue visit(final WhileStatement whileStatement)
    {
        String code = indent() + "Message.setLineNumber(" +
        whileStatement.getLineNumber() + ");\n";
        
        code += indent() + "while(true){\n";
        loop++;
        loopDepth.settop(loop);
        
        Encode.ReturnValue exp = visitNode(whileStatement.getExp());
        Statement stat = whileStatement.getStat();
        increaseIndentation();
        
        code += indent() + exp.code;
        code += indent() + "if(" +exp.result +".toBoolean().getInternal()"+"){\n";
        code += indent() + visitNode(stat).code;
        code += indent() + "} else\n";
        increaseIndentation();
        code += indent() + "break;\n";
        decreaseIndentation();
        
        decreaseIndentation();
        code += indent() + "}\n";
        
        loop--;
        loopDepth.settop(loop);
        
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a ifstatement. */
    public Encode.ReturnValue visit(final IfStatement ifStatement)
    {
        String code = indent() + "Message.setLineNumber(" +
        ifStatement.getLineNumber() + ");\n";
        
        Encode.ReturnValue exp = visitNode(ifStatement.getExp());
        Statement ifStat = ifStatement.getThenStat();
        Statement elseStat = ifStatement.getElseStat();
        
        code += exp.code;
        code += indent() + "if (" + exp.result + ".toBoolean().getInternal())\n";
        code += indent() + "{\n";
        code += indent() + indent() + visitNode(ifStat).code;
        if( elseStat != null )
        {
            code += "}else{\n";
            code += indent() + indent() + visitNode(elseStat).code;
        }
        code += "}\n";
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a breakstatement. */
    public Encode.ReturnValue visit(final BreakStatement breakStatement)
    {
        String code = indent() + "Message.setLineNumber(" +
        breakStatement.getLineNumber() + ");\n";
        
        if (loop == 0)
            Message.error(breakStatement.getLoc(), "breakStatement not in any loop");
        code += indent() + "if(true) break;\n";
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a continuestatement. */
    public Encode.ReturnValue visit(final ContinueStatement continueStatement)
    {
        String code = indent() + "Message.setLineNumber(" +
        continueStatement.getLineNumber() + ");\n";
        
        if (loop == 0)
            Message.error(continueStatement.getLoc(), "continueStatement not in any loop");
        code += indent() + "if(true) continue;\n";
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a throwstatement. */
    public Encode.ReturnValue visit(final ThrowStatement throwStatement)
    {
        //String code = indent();
        String code = indent() + "Message.setLineNumber(" +
        throwStatement.getLineNumber() + ");\n";
        
        Encode.ReturnValue exp = visitNode(throwStatement.getExp());
        code += exp.code;
        code += indent() + "if(true) throw new TSException(" + exp.result + ");\n";
        
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a trystatement. */
    public Encode.ReturnValue visit(final TryStatement tryStatement)
    {
        //String code = indent();
        String code = indent() + "Message.setLineNumber(" +
        tryStatement.getLineNumber() + ");\n";
        
        code += indent() + "try{\n";
        Encode.ReturnValue s1 = visitNode(tryStatement.getTryStat());
        code += s1.code;
        code += "}\n";
        if ( tryStatement.getCatchStat() != null )
        {
            code += visitNode(tryStatement.getCatchStat()).code;
        }
        
        if ( tryStatement.getFinalStat() != null )
        {
            code += visitNode(tryStatement.getFinalStat()).code;
        }
        
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a catchStatement. */
    public Encode.ReturnValue visit(final CatchStatement catchStatement)
    {
        String name = getTemp();
        String code = indent() + "catch( TSException "+ name + ") {\n";
        increaseIndentation();
        
        String evn0 = getEnv();
        
        code += indent() + "TSEnvironment " + evn0 + " = " +
        "TSEnvironment.newEnvironment("+currentEnv+");\n";
        
        enterNewEnv(evn0);
        inCatch.push(true);
        catchStr.push(catchStatement.getId());
        //decl parameter
        code += indent() + currentEnv+".declareParameter(" +"\"" +
        catchStatement.getId() + "\"," + name + ".getValue());\n";
        
        Encode.ReturnValue exp = visitNode(catchStatement.getCatchStat());
        code += exp.code;
        
        decreaseIndentation();
        code += indent() + "}\n";
        
        //get out of catch
        inCatch.pop();
        catchStr.pop();
        exitNewEnv();
        
        return new Encode.ReturnValue(code);
    }
    
    /** Generate and return code for a finallystatement. */
    public Encode.ReturnValue visit(final FinallyStatement finallyStatement)
    {
        String code = indent() + "finally {\n";
        Encode.ReturnValue s3 = visitNode(finallyStatement.getFinalStat());
        code += s3.code;
        code += indent() + "}\n";
        
        return new Encode.ReturnValue(code);
    }
    
    /** do nothing if visit arguments is called */
    public Encode.ReturnValue visit(final Arguments arguments)
    {
        return new Encode.ReturnValue(null);
    }
    
    /** Generate and return code for a returnstatement. */
    public Encode.ReturnValue visit(final ReturnStatement returnStatement)
    {
        if( funcDepth == 0 )
        {
            Message.error(returnStatement.getLoc(), "returnStatement not in any function");
        }
        
        String code = indent() + "Message.setLineNumber("
        + returnStatement.getLineNumber() + ");\n";
        String result = "";
        if(returnStatement.getExp()!=null)
        {
            Encode.ReturnValue val = visitNode(returnStatement.getExp());
            code += val.code;
            code += indent() + "if(true) return TSValue.make(" + val.result +");\n";
        }
        else
        {
            code += indent() + "if(true) return TSUndefined.value;\n";
        }
        
        return new Encode.ReturnValue(result,code);
    }
    
    /** Generate and return code for a function expression. */
    public Encode.ReturnValue visit(final FunctionExpression functionExpression)
    {
        String name = functionExpression.getName();
        ArrayList<String> paraList = functionExpression.getPara();
        ArrayList<Statement> statList = functionExpression.getBody();
        ArrayList<VarDec> forList = functionExpression.getForTable();
        
        enterNewContext();
        funcDepth++;
        
        String code = "";
        code += "public TSValue execute(boolean isConstructorCall, TSValue ths, " +
        "TSValue args[], TSEnvironment env){\n";
        increaseIndentation();
        
        code += "TSValue " + thisBind + " = ths.getValue();\n";
        code += indent() + "if(ths.isUndefined() || ths == null)\n";
        code += indent() + indent() + thisBind + " = TSObject.globalObject;\n";

        code += indent() + "try {\n";
        increaseIndentation();
        
        code += indent() + "TSEnvironment " + currentEnv + " = " +
        "TSEnvironment.newEnvironment(env);\n";
        int i = 0;
        if( forList != null )
        {
            for( VarDec var : forList )
            {
                String temp = var.getTempName();
                code += indent() + "TSValue " + temp + " = (" + i +
                " < args.length ? args[" + i + "] : TSUndefined.value);\n";
                i++;
            }
        }
        
        if(functionExpression.getTable() != null)
        {
            for( VarDec var : functionExpression.getTable() )
            {
                String temp = var.getTempName();
                code += indent() + "TSValue " + temp + " = TSUndefined.value;\n";
            }
        }
        
        if( statList != null )
        {
            for (Statement s : statList)
                code += visitNode(s).code;
        }
        
        decreaseIndentation();
        code += indent() + "} catch (TSException tse) {\n";
        increaseIndentation();
        code += indent() + "Message.executionError(tse.getMessage());\n";
        decreaseIndentation();
        code += indent()+"}\n";
        code += indent() + "return TSUndefined.value;\n";
        decreaseIndentation();
        code += "}\n";
        
        String fname = "Func"+funNum;
        funNum += 1;
        funcList.add( new Encode.ReturnValue(fname,code) );
        
        //System.out.println(code);
        
        exitNewContext();
        
        code = "";
        String temp1 = getTemp();
        String temp2 = getTemp();
        String env0 = currentEnv;
        
        if(name != null )
        {
            String env = getEnv();
            env0 = env;
            code += indent() + "TSEnvironment " + env + " = " +
            "TSEnvironment.newEnvironment("+currentEnv+");\n";
        }
        
        code += indent() + "TSCode " + temp1 + " = new " + funcList.get(funNum-1).result+"();\n";
        code += indent() + "TSValue " + temp2 + " = TSFunctionObject.create("+temp1+","+env0+");\n";
        
        if(name != null )
        {
            code += indent() + env0 + ".putFunction(\""+name+"\","+temp2+");\n";
        }
        
        funcDepth--;
        return new Encode.ReturnValue(temp2,code);
        
    }
    
    /** Generate and return code for a function call. */
    public Encode.ReturnValue visit(final FunctionCall functionCall)
    {
        String code = indent() + "Message.setLineNumber("
        + functionCall.getLineNumber() + ");\n";
        
        final Expression exp = functionCall.getExp();
        final Arguments args = functionCall.getArg();
        final ArrayList<Expression> arglist = args.getList();
        final Encode.ReturnValue getName = visitNode(exp);

        String temp0 = getTemp();
        String temp1 = getTemp();
        String temp2 = getTemp();
        
        code += getName.code;
        code += indent() + "TSValue " + temp0 + " = " + getName.result + ".getValue();\n";

        if( exp instanceof PropertyAccessor )
        {
            code += indent() + thisBind + " = " + ((PropertyAccessor) exp).getKey() + ";\n";
        }
        if( arglist != null )
        {
            int i = 0;
            code += indent() + "TSValue " + temp2 + "[] = new TSValue["+arglist.size()+"];\n";
            List<Encode.ReturnValue> val = visitEach(arglist);
            for (Encode.ReturnValue v : val)
            {
                code += v.code;
                code += indent() + temp2 +"["+i+"] = TSValue.make("+v.result+").getValue();\n";
                i++;
            }
            code += indent() + "TSValue "+temp1+" = TSUndefined.value;\n";
            //code += indent() + temp1 + " = ((TSFunctionObject)"+temp0;
            //code += ").runFunction(false,null,"+temp2+");\n";
            code += indent() + temp1 + " = ((TSFunctionObject)"+temp0;
            code += ").runFunction(false,"+thisBind+","+temp2+");\n";
        }
        else
        {
            code += indent() + "TSValue "+temp1+" = TSUndefined.value;\n";
            //code += indent() + temp1 + " = ((TSFunctionObject)"+temp0+ ").runFunction(false,null,null);\n";
            code += indent() + temp1 + " = ((TSFunctionObject)"+temp0+ ").runFunction(false,"+thisBind+",null);\n";
        }
        if( exp instanceof PropertyAccessor )
        {
            code += indent() + thisBind + " = TSObject.globalObject;\n";
        }
        return new Encode.ReturnValue(temp1,code);
    }
    
    /** Generate and return code for a PropertyAccessor. */
    public Encode.ReturnValue visit(final PropertyAccessor propertyAccessor)
    {
        String code = indent() + "Message.setLineNumber("
        + propertyAccessor.getLineNumber() + ");\n";
        
        final Encode.ReturnValue exp = visitNode(propertyAccessor.getExp());
        code += exp.code;
        String id = "";
        String temp0 = getTemp();
        if(propertyAccessor.getId() != null)
        {
            id = propertyAccessor.getId();
            code += indent() + "TSValue " + temp0 +" = "+ exp.result + ".get(\"" + id + "\");\n";
        }
        else
        {
            final Encode.ReturnValue exp1 = visitNode(propertyAccessor.getParam());
            code += exp1.code;
            id = exp1.result;
            String temp3 = getTemp();
            code += indent() + "String "+ temp3 + " = TSValue.make("+id+").toPrimitive().toStr().getInternal();\n";
            code += indent() + "TSValue " + temp0 +" = "+ exp.result + ".get(" + temp3 + ");\n";
        }
        propertyAccessor.setKey( exp.result );
        return new Encode.ReturnValue(temp0,code);
    }
    
    /** Generate and return code for a NewExpression. */
    public Encode.ReturnValue visit(final NewExpression newExpression)
    {
        String code = indent() + "Message.setLineNumber("
        + newExpression.getLineNumber() + ");\n";
        
        final Expression exp = newExpression.getExp();
        final Arguments args = newExpression.getArg();
        ArrayList<Expression> arglist = null;
        if( args != null )
        {
            arglist = args.getList();
        }
        final Encode.ReturnValue getName = visitNode(exp);
        
        String temp0 = getTemp();
        String temp1 = getTemp();
        code += getName.code;
        code += indent() + "TSValue[] " + temp1 + " = new TSValue[0];\n";
        code += indent() + "TSValue " + temp0 +" = "+ getName.result+".callConstructor("+ temp1 +");\n";
        return new Encode.ReturnValue(temp0,code);
    }
    
    public Encode.ReturnValue visit(final This ths)
    {
        return new Encode.ReturnValue(thisBind,"");
    }
}
