
package ts.tree.visit;

import ts.Message;
import ts.tree.*;
import ts.tree.type.*;
import static ts.tree.Binop.*;

import java.util.Deque;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;

/**
 * Analyze an AST. The goal is to do simple type inferencing and to
 * identify where variables will be stored at run-time. For now, they
 * they will be stored in a Java local, but later this code will need
 * to be updated to support variables captured by a closure, and global
 * variables stored as properties of the global object.
 * <p>
 * When the analyzer is created, a pass number is provided to the constructor,
 * which must be either 1 (first pass) or 2 (second pass). The first pass
 * connects Identifier nodes to the VarStatement nodes where the identifier
 * was declared. Information is accumulated in the VarStatement node about
 * the variable, including its function depth (how deeply nested is the
 * function that contains the declaration) and its type. A second pass is
 * needed because if the type is ambiguous for a variable, then its initial
 * uses may not reflect the ambiguous type that was found later. The expression
 * trees containing these Identifier nodes need to have their types updated
 * in the second pass.
 * <p>
 * Using Tree for the type parameter to allow subtrees to be altered
 * by visiting them. The return type can be assigned to the fields
 * of a node as the traversal returns back to it. This capability is
 * actually not being used, but it might be useful later.
 * <p>
 * The "visit" method is overloaded for each tree node type.
 */
public final class Analyze extends TreeVisitorBase<Tree>
{
    /** The symbol table. It is a map of variable names to stacks of
     *  Var declaration nodes.
     */
    private Map<String, Deque<VarDec>> symbolTable;
    
    /** The current function declaration depth. Always zero now. */
    private int functionDepth = 0;
    
    /** The pass being implemented by this instance of the analyze visitor.
     *  Must be either 1 (first pass) or 2 (second pass).
     */
    private int pass;
    
    /** Create an AST analyzer.
     *
     *  @param pass pass number to be implemented by this analyze visitor,
     *              which must be either 1 (first pass) or 2 (second pass).
     */
    public Analyze(int pass)
    {
        if (pass < 1 || pass > 2)
        {
            throw new IllegalArgumentException("illegal pass number");
        }
        this.pass = pass;
        symbolTable = new HashMap<String,Deque<VarDec>>();
    }
    
    /** Visit a list of ASTs and dump them in order.
     */
    @Override public List<Tree> visitEach(final Iterable<?> nodes)
    {
        for (final Object node : nodes)
        {
            visitNode((Tree) node);
        }
        return null;
    }
    
    /** Analyze a binary operator. */
    @Override public Tree visit(final BinaryOperator binaryOperator)
    {
        
        // recurse left and then right
        binaryOperator.setLeft((Expression)visitNode(binaryOperator.getLeft()));
        binaryOperator.setRight((Expression)visitNode(binaryOperator.getRight()));
        
        // now do type analysis
        Binop op = binaryOperator.getOp();
        Type leftType = null;
        Type rightType = null;
        
        if( binaryOperator.getLeft() instanceof PropertyAccessor )
        {
            leftType = UnknownType.getInstance();
        }
        else
        {
            leftType = binaryOperator.getLeft().getType();
        }
        
        if( binaryOperator.getRight() instanceof PropertyAccessor )
        {
            rightType = UnknownType.getInstance();
        }
        else
        {
            rightType = binaryOperator.getRight().getType();
        }
        
        switch (op)
        {
            case ADD:
                // if either operand is a string, then result is a string
                if (leftType.isStringType() || rightType.isStringType())
                {
                    binaryOperator.setType(StringType.getInstance());
                }
                // if both are numbers, then result is number
                else if (leftType.isNumberType() && rightType.isNumberType())
                {
                    binaryOperator.setType(NumberType.getInstance());
                }
                // otherwise can't tell now what result type will be
                else
                {
                    binaryOperator.setType(UnknownType.getInstance());
                }
                break;
            case SUBTRACT:
                // if both are numbers, then result is number
                binaryOperator.setType(NumberType.getInstance());
                break;
            case ASSIGN:
                // type of the result is the type of the right-hand side
                binaryOperator.setType(rightType);
                // if the left-hand side is an identifier, then on pass 1
                // update its declaring VarStatement node (if there is one)
                if ((pass == 1) && (binaryOperator.getLeft() instanceof Identifier))
                {
                    Identifier id = (Identifier) binaryOperator.getLeft();
                    VarDec node = id.getVarNode();
                    // might not be declared
                    if (node != null)
                    {
                        // update the type information recorded so far for variable
                        Type oldType = node.getType();
                        if (oldType == null)
                        {
                            // no type seen before
                            // always set to unknown type,
                            // otherwise the print statement would have error
                            node.setType(UnknownType.getInstance());
                        }
                        else
                        {
                            // if old type does not match the current type, then
                            // the type is ambigous
                            if (!oldType.isSameType(rightType))
                            {
                                // so label the variable as having unknown type
                                node.setType(UnknownType.getInstance());
                            }
                        }
                    }
                }
                
                //                if ((pass == 1) && (binaryOperator.getLeft() instanceof PropertyAccessor))
                //                {
                //                    binaryOperator.getLeft().setType(UnknownType.getInstance());
                //                }
                break;
            case MULTIPLY:
                // always produces a number
                binaryOperator.setType(NumberType.getInstance());
                break;
            case DIVIDE:
                // always produces a number
                binaryOperator.setType(NumberType.getInstance());
                break;
                
            case EQUALS:
                // always set as unknown
                binaryOperator.setType(UnknownType.getInstance());
                break;
                
            case LESS_THAN:
                // always set as unknown
                binaryOperator.setType(UnknownType.getInstance());
                break;
                
            case GREATER_THAN:
                // always set as unknown
                binaryOperator.setType(UnknownType.getInstance());
                break;
                
            default:
                Message.bug("unexpected binary operator");
        }
        // return this node so it can be re-assigned by its parent
        return binaryOperator;
    }
    
    /** Analyze a unary operator. */
    @Override public Tree visit(final UnaryOperator unaryOperator)
    {
        // recurse right
        unaryOperator.setRight((Expression)visitNode(unaryOperator.getRight()));
        
        // now do type analysis
        Unop op = unaryOperator.getOp();
        Type rightType = unaryOperator.getRight().getType();
        
        switch (op)
        {
            case USUBTRACT:
                // always set as unknown
                unaryOperator.setType(UnknownType.getInstance());
                break;
                
            case LOGICAL_NOT:
                // always set as unknown
                unaryOperator.setType(UnknownType.getInstance());
                break;
                
            default:
                Message.bug("unexpected unary operator");
        }
        
        // return this node so it can be re-assigned by its parent
        return unaryOperator;
    }
    
    
    /** Analyze an expression statement. */
    @Override public Tree visit(final ExpressionStatement expressionStatement)
    {
        visitNode(expressionStatement.getExp());
        return null;
    }
    
    /** Analyze an identifier. */
    @Override public Tree visit(final Identifier identifier)
    {
        // if it is the second pass then only need to copy the type from
        // the Var node.
        if (pass == 2)
        {
            VarDec varNode = identifier.getVarNode();
            if (varNode == null)
            {
                // identifier is undefined, so set its type to unknown
                identifier.setType(UnknownType.getInstance());
            }
            else
            {
                Type type = varNode.getType();
                if (type == null)
                {
                    // variable was never assigned so set the type to unknown
                    identifier.setType(UnknownType.getInstance());
                }
                else
                {
                    // otherwise use the type in the var node
                    identifier.setType(type);
                }
            }
            // that is all we need to do for pass 2
            return identifier;
        }
        
        //
        // all the following code is only executed on pass 1
        //
        
        // lookup the name in the symbol table
        Deque<VarDec> stack = symbolTable.get(identifier.getName());
        if (stack != null)
        {
            VarDec varNode = stack.peekFirst();
            if (varNode != null)
            {
                // record the declaration tree node into the identifier tree node so
                // that code generator has access to what is learned about this
                // variable
                identifier.setVarNode(varNode);
                
                // check the type field of the Var node
                // if it is null, and the identifier represents an Rval, then
                // this is a use of the variable before it is assigned to, meaning
                // that it will contain the undefined value, so its type needs
                // to be set to Unknown, since the variable lifetime is not
                // always Number or always String
                if (varNode.getType() == null && !identifier.isLval())
                {
                    varNode.setType(UnknownType.getInstance());
                    identifier.setType(UnknownType.getInstance());
                }
                else
                {
                    // otherwise set this type to be the type from the var node
                    identifier.setType(varNode.getType());
                }
            }
            else
            {
                // identifier is not defined, so set its type to Unknown
                identifier.setType(UnknownType.getInstance());
            }
        }
        else
        {
            // identifier is not defined, so set its type to Unknown
            identifier.setType(UnknownType.getInstance());
        }
        
        // return the node so that it can be re-assigned by its parent
        return identifier;
    }
    
    /** Analyze a numeric literal. */
    @Override public Tree visit(final NumericLiteral numericLiteral)
    {
        // always has Number type
        numericLiteral.setType(NumberType.getInstance());
        // return the node so that it can be re-assigned by its parent
        return numericLiteral;
    }
    
    /** Analyze a boolean literal. */
    @Override public Tree visit(final BooleanLiteral booleanLiteral)
    {
        // always has boolean type
        booleanLiteral.setType(UnknownType.getInstance());
        // return the node so that it can be re-assigned by its parent
        return booleanLiteral;
    }
    
    /** Analyze a Null literal. */
    @Override public Tree visit(final NullLiteral nullLiteral)
    {
        // always has Number type
        nullLiteral.setType(UnknownType.getInstance());
        // return the node so that it can be re-assigned by its parent
        return nullLiteral;
    }
    
    /** Analyze a print statement. */
    @Override public Tree visit(final PrintStatement printStatement)
    {
        visitNode(printStatement.getExp());
        return null;
    }
    
    /** Analyze a program. */
    @Override public Tree visit(final Program program)
    {
        visitEach(program.getList());
        if( pass == 1 )
        {
            //program.putTable(symbolTable);
            //symbolTable.clear();
            
            for( Map.Entry<String, Deque<VarDec>> entry : symbolTable.entrySet() )
            {
                if(!entry.getValue().isEmpty())
                    program.addVar(entry.getValue().peekFirst());
            }
            for( Map.Entry<String, Deque<VarDec>> entry : symbolTable.entrySet() )
            {
                if(!entry.getValue().isEmpty())
                    entry.getValue().pop();
            }
        }
        return null;
    }
    
    /** Analyze a string literal. */
    @Override public Tree visit(final StringLiteral stringLiteral)
    {
        // always has String type
        stringLiteral.setType(StringType.getInstance());
        
        // return the node so that it can be re-assigned by its parent
        return stringLiteral;
    }
    
    
    /** Analyze a object literal. */
    @Override public Tree visit(final ObjectLiteral objectLiteral)
    {
        // always has Unknown type
        objectLiteral.setType(UnknownType.getInstance());
        
        if(objectLiteral.getPara() != null)
        {
            for( Map.Entry<String, Expression> entry : objectLiteral.getPara().entrySet() )
            {
                visitNode( entry.getValue() );
            }
        }
        // return the node so that it can be re-assigned by its parent
        return objectLiteral;
    }
    
    /** Analyze an array literal. */
    @Override public Tree visit(final ArrayLiteral arrayLiteral)
    {
        // always has Unknown type
        arrayLiteral.setType(UnknownType.getInstance());
        
        if(arrayLiteral.getList() != null)
        {
            visitEach(arrayLiteral.getList());
        }
        // return the node so that it can be re-assigned by its parent
        return arrayLiteral;
    }
    
    /** Analyze a VarDec node. */
    @Override public Tree visit(final VarDec varDec )
    {
        // there is nothing to do if this is pass 2
        if (pass == 2)
        {
            return null;
        }
        //
        // the following code is only executed on pass 1
        //
        if(varDec.getValue()!=null)
            visitNode(varDec.getValue());
        
        // record the current function depth
        varDec.setFunctionDepth(functionDepth);
        
        // generate a temp name to use at codegen time
        varDec.setTempName("var_" + varDec.getName() + "_" + functionDepth);
        // is there a stack for this name already in the symbol table?
        Deque<VarDec> stack = symbolTable.get(varDec.getName());
        if (stack == null)
        {
            // need to create the stack and insert it into the map
            stack = new LinkedList<VarDec>();
            symbolTable.put(varDec.getName(), stack);
        }
        // is there a declaration for this variable at the same function depth?
        // if so, then mark this declaration as redundant.
        VarDec top = stack.peekFirst();
        if ((top != null) && (top.getFunctionDepth() == functionDepth))
        {
            varDec.setIsRedundant();
        }
        // else push the current VarStatment onto the stack
        else
        {
            stack.addFirst(varDec);
        }
        return null;
    }
    
    /** Analyze a var statement. */
    @Override public Tree visit(final VarStatement varStatement)
    {
        //traverse the list of variable in the statement
        visitEach(varStatement.getList());
        return null;
    }
    /** Analyze a blockstatement **/
    @Override public Tree visit(final BlockStatement blockStatement )
    {
        if(blockStatement.getValue() != null)
            visitEach( blockStatement.getValue() );
        return null;
    }
    
    /** Analyze a emptystatement, just do nothing **/
    @Override public Tree visit(final EmptyStatement emptyStatement )
    {
        return null;
    }
    
    /** Analyze a whilestatement **/
    @Override public Tree visit(final WhileStatement whileStatement )
    {
        visitNode(whileStatement.getExp());
        visitNode(whileStatement.getStat());
        return null;
    }
    
    /** Analyze a ifstatement **/
    @Override public Tree visit(final IfStatement ifStatement )
    {
        visitNode(ifStatement.getExp());
        visitNode(ifStatement.getThenStat());
        if (ifStatement.getElseStat()!=null)
            visitNode(ifStatement.getElseStat());
        return null;
    }
    
    /** Analyze an BreakStatement. */
    public Tree visit(final BreakStatement breakStatement)
    {
        return null;
    }
    
    /** Analyze an ContinueStatement. */
    public Tree visit(final ContinueStatement continueStatement)
    {
        return null;
    }
    
    
    /** Analyze a trystatement **/
    @Override public Tree visit(final TryStatement tryStatement )
    {
        if( tryStatement.getTryStat() != null )
        {
            visitNode(tryStatement.getTryStat());
        }
        
        if( tryStatement.getCatchStat() != null )
        {
            visitNode(tryStatement.getCatchStat());
        }
        
        if( tryStatement.getFinalStat() != null )
        {
            visitNode(tryStatement.getFinalStat());
        }
        return null;
    }
    
    /** Analyze a catchstatement **/
    @Override public Tree visit(final CatchStatement catchStatement )
    {
        
        visitNode(new Identifier(catchStatement.getLoc(), catchStatement.getId()));
        visitNode(catchStatement.getCatchStat());
        return null;
    }
    
    /** Analyze a finalstatement **/
    @Override public Tree visit(final FinallyStatement finallyStatement )
    {
        
        visitNode(finallyStatement.getFinalStat());
        return null;
    }
    
    /** Analyze a throwstatement **/
    @Override public Tree visit(final ThrowStatement throwStatement )
    {
        visitNode(throwStatement.getExp());
        return null;
    }
    
    /** Analyze an Arguments list.
     *  @param arguments Arguments
     *  @return null
     */
    @Override public Tree visit(final Arguments arguments)
    {
        if(arguments.getList() != null )
        {
            visitEach(arguments.getList());
        }
        return null;
    }
    
    /** Analyze a function call.
     *  @param functionCall functionCall
     *  @return null
     */
    @Override public Tree visit(final FunctionCall functionCall)
    {
        functionCall.setType(UnknownType.getInstance());
        visitNode(functionCall.getExp());
        if(functionCall.getArg() != null )
            visitNode(functionCall.getArg());
        return functionCall;
    }
    
    /** Analyze a return statement
     *  @param returnStatement returnStatement
     *  @return null
     */
    @Override public Tree visit(final ReturnStatement returnStatement)
    {
        if(returnStatement.getExp() != null )
            visitNode(returnStatement.getExp());
        return null;
    }
    
    /** Analyze a PropertyAccessor
     *  @param propertyAccessor propertyAccessor
     *  @return null
     */
    @Override public Tree visit(final PropertyAccessor propertyAccessor)
    {
        propertyAccessor.setType(UnknownType.getInstance());
        if((propertyAccessor.getExp()) != null )
        {
            visitNode(propertyAccessor.getExp());
        }
        if((propertyAccessor.getParam()) != null )
        {
            visitNode(propertyAccessor.getParam());
        }
        return propertyAccessor;
    }
    
    /** Analyze a NewExpression
     *  @param newExpression newExpression
     *  @return newExpression
     */
    @Override public Tree visit(final NewExpression newExpression)
    {
        newExpression.setType(UnknownType.getInstance());
        if((newExpression.getExp()) != null )
        {
            visitNode(newExpression.getExp());
        }
        if((newExpression.getArg()) != null )
        {
            visitNode(newExpression.getArg());
        }
        return newExpression;
    }
    
    /** Analyze a thisExpression
     *  @param ths this
     *  @return ths this
     */
    @Override public Tree visit(final This ths)
    {
        ths.setType(UnknownType.getInstance());
        return ths;
    }
    
    /** Analyze a function expression
     *  @param functionExpression functionExpression
     *  @return null
     */
    @Override public Tree visit(final FunctionExpression functionExpression)
    {
        functionDepth += 1;
        //add all parameter identifier to symboltable
        //and save them to functionexpression
        if(functionExpression.getPara() != null)
        {
            for(String s : functionExpression.getPara())
            {
                VarDec varDec = new VarDec( functionExpression.getLoc(), s, null );
                varDec.setFunctionDepth(functionDepth);
                varDec.setTempName("formal_" + s + "_" + functionDepth);
                varDec.setFormal();
                Deque<VarDec> stack = symbolTable.get(s);
                if( stack == null )
                {
                    stack = new LinkedList<VarDec>();
                    symbolTable.put(s, stack);
                }
                //System.out.println("now add formal parameter " + s);
                stack.addFirst(varDec);
            }
        }
        
        if(functionExpression.getBody() != null)
        {
            for( Statement s: functionExpression.getBody() )
                visitNode(s);
        }
        if(pass == 1)
        {
            for( Map.Entry<String, Deque<VarDec>> entry : symbolTable.entrySet() )
            {
                if(!entry.getValue().isEmpty() &&
                   entry.getValue().peekFirst().getFunctionDepth() == functionDepth )
                {
                    if( entry.getValue().peekFirst().isFormal() )
                    {
                        functionExpression.addFormal(entry.getValue().peekFirst());
                    }
                    else
                    {
                        functionExpression.addVar(entry.getValue().peekFirst());
                    }
                    entry.getValue().pop();
                }
            }
        }
        
        functionDepth -= 1;
        return functionExpression;
    }
}

