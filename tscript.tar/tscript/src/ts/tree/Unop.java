
package ts.tree;

/**
 * enum for binary operator names
 *
 */
public enum Unop { USUBTRACT, LOGICAL_NOT }

