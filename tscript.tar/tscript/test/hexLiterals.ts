// test hex literals embedded in strings

var i;
i = "0x100";
console.log(i*1);

i = "0X200";
console.log(i*1);

i = "200";
console.log(i*1);

i = "0xabcdef";
console.log(i*1);

i = "0xABCDEF";
console.log(i*1);

i = "0x123ABC";
console.log(i*1);

i = "0x456DEF";
console.log(i*1);

i = "0x7890af";
console.log(i*1);

