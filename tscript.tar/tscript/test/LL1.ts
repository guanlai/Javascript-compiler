// program to calcualte LL(1)
productions = [];
startSymbol = [];
nonTerminal = [];
terminal = [];
nullDerive = [];
firstSet=[];
followSet=[];
predictSet=[];
result=[];

//console.log("------ Please enter grammer ------");
//console.log("---- One production per line -----");
//console.log("---- Use Ctrl+d when finish ------");

//
//------- input -------------------------------------------------
//
//read in all productions and stored as array of array
while(true)
{
	x = readln();
	if(!x)
	{		
		break;
	}
	y = split(x, " ");
	productions.push(y);
}

//
//------- start symbol ---------------------------------------
//
//get the start symbol and output
if(productions.length>0)
{
	startSymbol.push(productions[0][0]);
}
console.log("Start Symbol\n");
console.log(startSymbol[0]);
console.log("");

//
//------- non terminal set ---------------------------------------
//
//get the non terminal symbol and output
console.log("Nonterminals\n");
//traverse the array of productions, and add left symbol to Nonterminal
i = 0;
while(i<productions.length)
{
	if(nonTerminal.length == 0)
	{//if nonTerminal is empty, just push
		nonTerminal.push(productions[i][0]);
		i = i+1;
		continue;
	}
	j = 0;
	
	//for each push, we need to check if the non terminal is already in the set
	while(j<nonTerminal.length)
	{
		if(productions[i][0] == nonTerminal[j])
		{
			break;
		}
		j = j+1;
	}
	//search to the end, then push left symbol to nonterminal
	if(j==nonTerminal.length)
	{
		nonTerminal.push(productions[i][0]);
	}
	i = i+1;
}
//output nonTerminal
console.log(nonTerminal.toStr());
console.log("");


//
//------- terminal set ---------------------------------------
//
//get the terminal symbol and output
console.log("Terminals\n");

i = 0;
while(i<productions.length)
{
	//for each production, we check every elements
	//if they are not in nonterminal set, add to terminal set
	j = 1;
	while(j<productions[i].length)
	{
		a=productions[i][j];
		k = 0;
		//check if in nonterminal
		while(k<nonTerminal.length)
		{
			if(a==nonTerminal[k])
			{
				break;
			}
			k=k+1;
		}
		//if not in nonterminal, continue to check if it already in terminal
		if(k==nonTerminal.length)
		{
			l = 0;
			while(l<terminal.length)
			{
				if(a==terminal[l])
				{
					break;
				}
				l=l+1;
			}
			//search to the end, push it into terminal set
			if(l==terminal.length)
			{
				terminal.push(a);
			}
		}
		j=j+1;
	}
	//increase i to traverse all productions
	i = i+1;
}

console.log(terminal.toStr());
console.log("");

//
//------- null derive set ----------------------------------------
//
//get the Null-Deriving Nonterminals symbol and output
console.log("Null-Deriving Nonterminals\n");
i = 1; // i is the flag to control if we have updates
j = 0; // j is used to access each production

//first add those nonterminal directly derive to null
k = 0;
while(k<productions.length)
{
	if(productions[k].length==1)
	{
		nullDerive.push(productions[k][0]);
	}
	k=k+1;
}

while(0<i)
{	
	i=0;
	j=0;
	//then check if all elements in right hand side are null deriving
	while(j<productions.length)
	{
		k=1;
		while(k<productions[j].length)
		{
			b = productions[j][k];
			l=0;
			while(l<nullDerive.length)
			{
				if(b==nullDerive[l])
				{
					break;
				}
				l=l+1;
			}
			//if not null derive, break
			//else keep checking next symbol
			if(l==nullDerive.length)
			{
				break;
			}
			k=k+1;
		}
		//if the entire right hand side can derive to null
		//add left side symbol to null deriving set
		if(k==productions[j].length)
		{
			b=productions[j][0];
			l=0;
			while(l<nullDerive.length)
			{
				if(b==nullDerive[l])
				{
					break;
				}
				l=l+1;
			}
			//always check if the symbol already in the set
			if(l==nullDerive.length)
			{
				nullDerive.push(productions[j][0]);
				i=1;
			}			
		}
		j=j+1;
	}

}

console.log(nullDerive.toStr());
console.log("");

//
//------- first set -------------------------------------------------
//
// 
console.log("First Sets\n");
i = 0;
// initialize the first set matrix
while(i<nonTerminal.length)
{
	a=[];
	a.push(nonTerminal[i]);
	a.push(":");
	firstSet.push(a);
	i=i+1;
}

//calcualte first set
i=1;//i is the flag to check if we have updates
j=0;
while(0<i)
{
	i=0;
	j=0;
	//traverse the productions set to update first set
	while(j<productions.length)
	{
		if(productions[j].length==1)
		{//if null derive, do nothing
			j=j+1;
			continue;
		}
		
		k=1;
		while(k<productions[j].length)
		{//start from k=1, collect all first set of null deriving nonterminal
			c=productions[j][k];
			//check if c is terminal
			l=0;
			while(l<terminal.length)
			{
				if(c==terminal[l])
				{
					break;
				}
				l=l+1;
			}
			if(l<terminal.length)
			{//found terminal, add to first set and stop
				m=0;
				while(m<nonTerminal.length)
				{
					if(firstSet[m][0]==productions[j][0])
					{
						n=0;
						while(n<firstSet[m].length)
						{
							if(firstSet[m][n]==c)
							{
								break;
							}
							n=n+1;
						}
						if(n==firstSet[m].length)
						{
							firstSet[m].push(c);
							i=1;
						}
					}
					m=m+1;
				}
				break;
			}
			//add first set of this non terminal to first set of left
			m=0;
			while(m<nonTerminal.length)
			{
				if(firstSet[m][0]==productions[j][0])
				{
					break;
				}
				m=m+1;
			}
			n=0;
			while(n<nonTerminal.length)
			{
				if(firstSet[n][0]==c)
				{
					break;
				}
				n=n+1;
			}			
			l=2;
			while(l<firstSet[n].length)
			{
				o=2;
				while(o<firstSet[m].length)
				{
					if(firstSet[m][o]==firstSet[n][l])
					{
						break;
					}
					o=o+1;
				}
				if(o==firstSet[m].length)
				{
					firstSet[m].push(firstSet[n][l]);
					i=1;
				}
				l=l+1;
			}
			
			//check if non terminal is null derive
			l=0;
			while(l<nullDerive.length)
			{
				if(c==nullDerive[l])
				{
					break;
				}
				l=l+1;
			}
			if(l==nullDerive.length)
			{//not null derive, just add first set of this non terminal then break
				break;
			}
			//add first set of this non terminal, and increse k to go another round
			k=k+1;
		}
		j=j+1;
	}
}
//output the first set
i = 0;
while(i<nonTerminal.length)
{
	console.log(firstSet[i].toStr());
	i=i+1;
}
console.log("");

//
//------- follow set -------------------------------------------------
//
console.log("Follow Sets\n");
i = 0;
// initialize the follow set matrix
while(i<nonTerminal.length)
{
	a=[];
	a.push(nonTerminal[i]);
	a.push(":");
	followSet.push(a);
	i=i+1;
}
//add EOF to the follow set of start symbol
followSet[0].push("EOF");

//calcualte follow set
i=1;
while(0<i)
{
	i=0;
	j=0;
	while(j<productions.length)
	{
		//console.log("now process "+productions[j].toStr());
		if(productions[j].length==1)
		{//null derive, do nothing
			j=j+1;
			continue;
		}
		//update the follow set of right most element
		//first check if it is terminal, if yes, do nothing
		k=productions[j].length;
		c=productions[j][k-1];
		l=0;
		while(l<terminal.length)
		{
			if(c==terminal[l])
			{
				break;
			}
			l=l+1;
		}
		//the right most one is non terminal
		if(l==terminal.length)
		{
			left=productions[j][0];

			while(1<k)
			{
				c=productions[j][k-1];
				m=0;
				n=0;
				//find the index of right most symbol in the followSet
				while(m<followSet.length)
				{
					if(c==followSet[m][0])
					{
						break;
					}
					m=m+1;
				}
				if(m==followSet.length)
				{
					break;
				}
				//find the index of left most symbol in the followSet
				while(n<followSet.length)
				{
					if(left==followSet[n][0])
					{
						break;
					}
					n=n+1;
				}
		
				l=2;
				while(l<followSet[n].length)
				{
					p=2;
					while(p<followSet[m].length)
					{
						if(followSet[n][l]==followSet[m][p])
						{
							break;
						}
						p=p+1;
					}
					//udpate follow set, alwasys check for duplicate element and reset i to 1
					if(p==followSet[m].length)
					{
						followSet[m].push(followSet[n][l]);
						i=1;
					}
					l=l+1;
				}
				l=0;
				while(l<nullDerive.length)
				{
					if(c==nullDerive[l])
					{
						break;
					}
					l=l+1;
				}
				//if the right most element is null deriving, keep going leftward
				if(l<nullDerive.length)
				{
					k=k-1;
				}
				else
				{
					break;
				}
			}
		}
		
		//now update follow set by adding the first set of following expression
		if(productions[j].length<3)
		{
			j=j+1;
			continue;
		}
		k=1;
		while(k+1<productions[j].length)
		{
			left=productions[j][k];
			//if left is terminal, do nothing
			o=0;
			while(o<terminal.length)
			{
				if(left==terminal[o])
				{
					break;
				}
				o=o+1;
			}
			if(o<terminal.length)
			{
				k=k+1;
				continue;
			}
			
			//add the first set of right to the followset of left
			//if right is terminal, add right
			//if right is not null derive, add first set of right
			//if right is null deriving, keep going
			l=k+1;
			while(l<productions[j].length)
			{
				right=productions[j][l];
				//check if right is terminal
				o=0;
				while(o<terminal.length)
				{
					if(right==terminal[o])
					{
						break;
					}
					o=o+1;
				}
				
				m=0;
				n=0;
				while(m<followSet.length)
				{
					if(left==followSet[m][0])
					{
						break;
					}
					m=m+1;
				}
				
				if(o<terminal.length)
				{
					n=0;
					while(n<followSet[m].length)
					{
						if(right==followSet[m][n])
						{
							break;
						}
						n=n+1;
					}
					if(n==followSet[m].length)
					{
						followSet[m].push(right);
						i=1;
					}
					break;
				}
				
				n=0;
				while(n<firstSet.length)
				{
					if(right==firstSet[n][0])
					{
						break;
					}
					n=n+1;
				}
				
				// console.log("now right is ");
				// console.log(firstSet[n][0]);
				//now add the first set of right to the follow set of left
				o=2;
				while(o<firstSet[n].length)
				{
					p=2;
					while(p<followSet[m].length)
					{
						if(followSet[m][p]==firstSet[n][o])
						{
							break;
						}
						p=p+1;
					}
					if(p==followSet[m].length)
					{
						followSet[m].push(firstSet[n][o]);
					}
					o=o+1;
				}
				
				
				//if right null deriving, keep going
				o=0;
				while(o<nullDerive.length)
				{
					if(right==nullDerive[o])
					{
						break;
					}
					o=o+1;
				}
				if(o==nullDerive.length)
				{
					break;
				}
				l=l+1;
			}				
			k=k+1;
		}		
		j=j+1;
	}
}

//output the follow set
i = 0;
while(i<nonTerminal.length)
{
	console.log(followSet[i].toStr());
	i=i+1;
}
console.log("");

//
//------- predict set -------------------------------------------------
//
console.log("Predict Sets\n");
i = 0;
// initialize the predict set matrix
while(i<productions.length)
{
	a=[];
	predictSet.push(a);
	i=i+1;
}

//calcualte predict set
i=0;
while(i<productions.length)
{
	if(productions[i].length==1)
	{
//if predict size is 1, use the follow set of left element
		j=0;
		while(j<followSet.length)
		{
			if(followSet[j][0]==productions[i][0])
			{
				break;
			}
			j=j+1;
		}
		k=2;
		while(k<followSet[j].length)
		{
			predictSet[i].push(followSet[j][k]);
			k=k+1;
		}
		i=i+1;
		continue;
	}
//add the first set of all right part
	j=1;
 	while(j<productions[i].length)
	{
		//first check if terminal
		k=0;
		while(k<terminal.length)
		{
			if(productions[i][j]==terminal[k])
			{
				break;
			}
			k=k+1;
		}
		if(k<terminal.length)
		{
			l=0;
			while(l<predictSet[i].length)
			{
				if(predictSet[i][l]==productions[i][j])
				{
					break;
				}
				l=l+1;
			}
			if(l==predictSet[i].length)
			{
				predictSet[i].push(productions[i][j]);
			}
			break;
		}
		//now add first set of non terminal
		k=0;
		while(k<firstSet.length)
		{
			if(firstSet[k][0]==productions[i][j])
			{
				break;
			}
			k=k+1;
		}
		l=2;
		while(l<firstSet[k].length)
		{
			m=0;
			while(m<predictSet[i].length)
			{
				if(predictSet[i][m]==firstSet[k][l])
				{
					break;
				}
				m=m+1;
			}
			if(m==predictSet[i].length)
			{
				predictSet[i].push(firstSet[k][l]);
			}
			l=l+1;
		}
		//now check if current nonterminal is null deriving
		//if yes, keep going, if no, break
		k=0;
		while(k<nullDerive.length)
		{
			if(nullDerive[k]==productions[i][j])
			{
				break;
			}
			k=k+1;
		}
		if(k==nullDerive.length)
		{
			break;
		}
		else
		{
			j=j+1;
		}
	}
//if entire right part is null deriving, also add the follow set of left element
	if(j==productions[i].length)
	{
		j=0;
		while(j<followSet.length)
		{
			if(followSet[j][0]==productions[i][0])
			{
				break;
			}
			j=j+1;
		}
		k=2;
		while(k<followSet[j].length)
		{
			l=0;
			while(l<predictSet[i].length)
			{
				if(l<predictSet[i][l]==followSet[j][k])
				{
					break;
				}
				l=l+1;
			}
			if(l==predictSet[i].length)
			{
				predictSet[i].push(followSet[j][k]);
			}
			k=k+1;
		}
	}
	i=i+1;
}

//output the predict set
i = 0;
while(i<productions.length)
{
	console.log(productions[i].toStr());
	console.log(predictSet[i].toStr());
	console.log("");
	i=i+1;
}


//
//------- final result -------------------------------------------------
//
ll=true;
i=0;
// initialize the result set matrix
while(i<nonTerminal.length)
{
	a=[];
	a.push(nonTerminal[i]);
	a.push(":");
	result.push(a);
	//console.log(result[i].length);
	i=i+1;
}

i=0;
while(i<predictSet.length)
{
	j=0;
	while(j<result.length)
	{
		if(result[j][0]==productions[i][0])
		{
			break;
		}
		j=j+1;
	}
	
	//now copy every element in the predict set to the corresponding result of non terminal
	//if found duplicate symbol, set flag to false and stop
	k=0;
	while(k<predictSet[i].length)
	{
		l=0;
		//console.log(result[j].length);
		while(l<result[j].length)
		{
			if(result[j][l]==predictSet[i][k])
			{
				ll=false;
				break;
			}
			l=l+1;
		}

		if(l==result[j].length)
		{
			result[j].push(predictSet[i][k]);
		}
		else
		{
			break;
		}
		k=k+1;
	}
	if(k<predictSet[i].length)
	{
		break;
	}
	i=i+1;
}

//output final result
if(ll)
{
	console.log("The grammar is LL(1).\n");
}
else
{
	console.log("The grammar is NOT LL(1).\n");
}

















