//
// test operators
//

console.log(1+2*3);
console.log(3*2+1);
console.log((1+2)*3);
console.log(1+2+3);
console.log(2*3*4);

var abc;
var def;

console.log(abc = def = 42);
console.log(abc + def);

console.log(abc = 1 + 2 * 3);

console.log("2" * "21");

var x;
x = 12;
x = "12";
console.log(x * 9);
console.log(9 * x);
console.log(x * x);
console.log(9 * 9);
console.log(9 * "9");
console.log("9" * 9);
console.log(x * "9");
console.log("9" * x);

console.log(x + 9);
console.log(9 + x);
console.log(x + x);
console.log(9 + 9);
console.log(9 + "9");
console.log("9" + 9);
console.log(x + "9");
console.log("9" + x);

