// variable is declared twice

var x;

x = 18;

var x;

console.log(x);

var y;

console.log(y);

y = 19;

var y;

console.log(y);

