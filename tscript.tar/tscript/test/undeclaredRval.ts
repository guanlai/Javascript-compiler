//
// The use of an undeclared identifier is a run-time error.
//

var abc;

abc = 5;

console.log(abc + def);

