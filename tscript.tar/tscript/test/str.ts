// test string literals and string concatenation

var s;

s = "hello";

console.log(s);

s = s + s;

console.log(s);

s = "41";

s = s + 1;

console.log(s);

s = 1 + s;

console.log(s);

var x;

s = s + x;

console.log(s);

s = x + s;

console.log(s);

